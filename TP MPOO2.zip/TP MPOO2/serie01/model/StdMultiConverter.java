package serie01.model;

import serie01.util.Currency;
import serie01.util.CurrencyId;
import util.Contract;

public class StdMultiConverter implements MultiConverter {

    // ATTRIBUTS

    private Currency[] currencies;
    private double amount;

    // CONSTRUCTEURS

    public StdMultiConverter(int n) {
        Contract.checkCondition(n >= 2,
                "StdMultiConverter : Nombre de devise insuffisant");

        currencies = new Currency[n];
        amount = 0;
        for (int i = 0; i < n; i++) {
            currencies[i] = Currency.get(CurrencyId.EUR);
        }
    }

    // REQUETES

    @Override
    public double getAmount(int index) {
        Contract.checkCondition(0 <= index && index < getCurrencyNb(),
                "getAmount : Indice de devise incorrect");

        return amount * currencies[index].getExchangeRate()
                / Currency.get(CurrencyId.EUR).getExchangeRate();
    }

    @Override
    public Currency getCurrency(int index) {
        Contract.checkCondition(0 <= index && index < getCurrencyNb(),
                "getCurrency : Indice de devise incorrect");

        return currencies[index];
    }

    @Override
    public int getCurrencyNb() {
        return currencies.length;
    }

    @Override
    public double getExchangeRate(int index1, int index2) {
        Contract.checkCondition(0 <= index1 && index1 < getCurrencyNb() && 0
                <= index2 && index2 < getCurrencyNb(),
                "getExchangeRate : Indice de devise incorrect");

        return currencies[index2].getExchangeRate()
                / currencies[index1].getExchangeRate();
    }

    // COMMANDES

    @Override
    public void setAmount(int index, double amount) {
        Contract.checkCondition(0 <= index && index < getCurrencyNb(),
                "setAmount : Indice de devise incorrect");
        Contract.checkCondition(amount >= 0.0,
                "setAmount : Valeur négative");

        this.amount = amount / currencies[index].getExchangeRate()
                * Currency.get(CurrencyId.EUR).getExchangeRate();
    }

    @Override
    public void setCurrency(int index, Currency c) {
        Contract.checkCondition(0 <= index && index < getCurrencyNb(),
                "setCurrency : Indice de devise incorrect");
        Contract.checkCondition(c != null, "setCurrency : c == null");

        currencies[index] = c;
        setAmount(index, amount);
    }
}
