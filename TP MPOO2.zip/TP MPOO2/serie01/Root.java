package serie01;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import serie01.gui.Converter;
import serie01.util.DBFactory;

public final class Root {

    private Root() {
        // rien ici
    }

    private static void initDBType() {
        boolean done = false;
        while (!done) {
            DBTypes selection = (DBTypes) JOptionPane.showInputDialog(
                    null,
                    "Choissisez la source des données :",
                    "Création de la base de données",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    DBTypes.values(),
                    DBTypes.INTERNAL);
            if (selection != null) {
                try {
                    done = selection.createDB();
                } catch (UnsupportedOperationException e) {
                    JOptionPane.showMessageDialog(
                            null,
                            "L'accès à ce type de bd n'est pas implémenté",
                            "Connexion à une base de données",
                            JOptionPane.WARNING_MESSAGE
                    );
                }
            } else {
                System.out.println("pas de base de données, pas de jouet !");
                done = true;
            }
        }
    }

    private enum DBTypes {
        INTERNAL("Tableau mémoire") {
            @Override boolean createDB() {
                DBFactory.createInternalDB();
                return true;
            }
        },
        LOCAL("Fichier local") {
//            @Override boolean createDB() {
//                boolean created = false;
//                JFileChooser jfc = new JFileChooser();
//                int returnVal = jfc.showOpenDialog(null);
//                if (returnVal == JFileChooser.APPROVE_OPTION) {
//                    File f = jfc.getSelectedFile();
//                    try {
//                        DBFactory.createLocalDB(f);
//                        created = true;
//                    } catch (IOException e) {
//                        // rien : on retournera false
//                    }
//                }
//                return created;
//            }
        },
        REMOTE("SGBD distant");

        private final String name;
        DBTypes(String name) {
            this.name = name;
        }
        @Override public String toString() {
            return name;
        }
        boolean createDB() {
            throw new UnsupportedOperationException();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                initDBType();
                new Converter(5).display();
            }
        });
    }
}
