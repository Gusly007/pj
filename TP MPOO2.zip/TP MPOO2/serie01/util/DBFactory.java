package serie01.util;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import util.Contract;

public final class DBFactory {
    private DBFactory() {
       // rien
    }

    public static void createInternalDB() {
        Currency.setDB(new StdCurrencyDB());
    }

    public static void createLocalDB(File f) throws IOException {
        Contract.checkCondition(f != null);

        throw new UnsupportedOperationException();
    }

    public static void createRemoteDB(URL url) {
        Contract.checkCondition(url != null, "héhé");

        throw new UnsupportedOperationException();
    }
}
