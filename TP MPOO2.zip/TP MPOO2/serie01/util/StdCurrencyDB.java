package serie01.util;

import util.Contract;

public class StdCurrencyDB implements CurrencyDB {

    // ATTRIBUTS

    private final CurrencyId[] values;
    private double[] rates;

    // CONSTRUCTEURS

    public StdCurrencyDB() {
        values = CurrencyId.values();
        rates = new double[values.length];
        for (int i = 0; i < values.length; i++) {
            rates[i] = values[i].getRateForYear2001();
        }
    }

    // REQUETES

    @Override
    public double getExchangeRate(CurrencyId id) {
        Contract.checkCondition(id != null, "getExchangeRate : id == null");

        return rates[id.ordinal()];
    }

    @Override
    public String getIsoCode(CurrencyId id) {
        Contract.checkCondition(id != null, "getIsoCode : id == null");

        return id.getIsoCode();
    }

    @Override
    public String getCountry(CurrencyId id) {
        Contract.checkCondition(id != null, "getCountry : id == null");

        return id.getCountry();
    }

    @Override
    public String getName(CurrencyId id) {
        Contract.checkCondition(id != null, "getName : id == null");

        return id.getName();
    }

    // COMMANDES

    @Override
    public void setExchangeRate(CurrencyId id, double rate) {
        Contract.checkCondition(id != null, "setExchangeRate : id == null");
        Contract.checkCondition(rate > 0,
                "setExchangeRate : taux négatif ou nul");

        rates[id.ordinal()] = rate;
    }

}
