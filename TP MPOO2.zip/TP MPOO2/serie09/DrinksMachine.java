package serie09;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import serie06.CoinTypes;
import serie06.DrinkTypes;

public class DrinksMachine {

    // ATTRIBUTS

    private JFrame mainFrame;
    private JLabel changeInformation;
    private JLabel creditInformation;
    private Map<JButton, DrinkTypes> drinksButtons;
    private JButton insertButton;
    private JTextField coinInputField;
    private JButton cancelButton;
    private JTextField drinkOutputField;
    private JTextField changeOutputField;
    private JButton consumeButton;
    private DrinksMachineModel model;

    // CONSTRUCTEURS

    public DrinksMachine() {
        createModel();
        createView();
        placeComponents();
        createController();
    }

    // COMMANDES

    /**
     * Rend l'application visible au centre de l'écran.
     */
    public void display() {
        refresh();
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    // OUTILS

    private void createModel() {
        model = new StdDrinksMachineModel();
        for (CoinTypes c:CoinTypes.values()) {
        model.fillCash(c,
                (int) (Math.random() * DrinksMachineModel.MAX_COIN) + 1);
        }
    }

    private void createView() {
        mainFrame = new JFrame("Distributeur de boissons");

        changeInformation = new JLabel();

        creditInformation = new JLabel();

        drinksButtons = new LinkedHashMap<JButton, DrinkTypes>();
        for (DrinkTypes d: DrinkTypes.values()) {
            drinksButtons.put(new JButton(d.toString()), d);
        }

        insertButton = new JButton("Insérer");

        coinInputField = new JTextField();
        coinInputField.setHorizontalAlignment(JTextField.RIGHT);
        coinInputField.setColumns(5);

        cancelButton = new JButton("Annuler");

        drinkOutputField = new JTextField();
        drinkOutputField.setHorizontalAlignment(JTextField.CENTER);
        drinkOutputField.setEditable(false);
        drinkOutputField.setColumns(10);


        changeOutputField = new JTextField();
        changeOutputField.setHorizontalAlignment(JTextField.RIGHT);
        changeOutputField.setEditable(false);
        changeOutputField.setColumns(5);


        consumeButton = new JButton("Prenez votre boisson et/ou votre monnaie");
    }

    private void placeComponents() {

        JPanel p = new JPanel(); {
            p.setLayout(new GridLayout(2, 1));
            JPanel q = new JPanel(); {
                q.setLayout(new FlowLayout(FlowLayout.CENTER));
                q.add(changeInformation);
            }
            p.add(q);
            q = new JPanel(); {
                q.setLayout(new FlowLayout(FlowLayout.CENTER));
                q.add(creditInformation);
            }
            p.add(q);
        }
        mainFrame.add(p, BorderLayout.NORTH);

        p = new JPanel(); {
            p.setLayout(new GridLayout(0, 2));
            for (JButton b:drinksButtons.keySet()) {
                p.add(b);
                JLabel q = new JLabel(); {
                    q.setText(" "
                + String.valueOf(drinksButtons.get(b).getPrice()) + " cents");
                }
                p.add(q);
            }
        }
        mainFrame.add(p, BorderLayout.WEST);

        p = new JPanel(); {
            p.setLayout(new FlowLayout(FlowLayout.CENTER));
            JPanel q = new JPanel(); {
                q.setLayout(new GridLayout(2, 2));
                q.add(insertButton);
                JPanel r = new JPanel(); {
                    r.setLayout(new FlowLayout(FlowLayout.CENTER));
                    r.add(coinInputField);
                    r.add(new JLabel("cents"));
                }
                q.add(r);
                q.add(cancelButton);
            }
            p.add(q);
        }
        mainFrame.add(p, BorderLayout.EAST);

        p = new JPanel(); {
            p.setLayout(new GridLayout(2, 1));
            JPanel q = new JPanel(); {
                q.setLayout(new GridLayout(1, 2));
                JPanel r = new JPanel(); {
                    r.setLayout(new FlowLayout(FlowLayout.CENTER));
                    r.add(new JLabel("Boisson:"));
                    r.add(drinkOutputField);
                }
                q.add(r);
                r = new JPanel(); {
                    r.setLayout(new FlowLayout(FlowLayout.CENTER));
                    r.add(new JLabel("Monnaie:"));
                    r.add(changeOutputField);
                    r.add(new JLabel("cents"));
                }
                q.add(r);
            }
            p.add(q);
            q = new JPanel(); {
                q.setLayout(new FlowLayout(FlowLayout.CENTER));
                q.add(consumeButton);
            }
            p.add(q);
        }
        mainFrame.add(p, BorderLayout.SOUTH);

    }

    private void createController() {

        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        model.addObserver(new Observer() {
            @Override
            public void update(Observable o, Object arg) {
                refresh();
            }
        });

        ActionListener a = new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                DrinkTypes d = drinksButtons.get(e.getSource());
                if (model.getCreditAmount() >= d.getPrice()) {
                    if (model.getLastDrink() == null) {
                        model.selectDrink(d);
                    } else {
                        JOptionPane.showMessageDialog(
                            null,
                            "Veuillez récupérer votre boisson",
                            "Erreur !",
                            JOptionPane.INFORMATION_MESSAGE
                        );
                    }
                }

            }
        };

        for (JButton b:drinksButtons.keySet()) {
            b.addActionListener(a);
        }

        insertButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    CoinTypes c = CoinTypes.getCoinType(
                            Integer.parseInt(coinInputField.getText()));
                    if (c == null) {
                        throw new NumberFormatException();
                    } else {
                        coinInputField.setText("");
                        model.insertCoin(c);
                    }
                } catch (NumberFormatException exception) {
                    coinInputField.selectAll();
                    coinInputField.requestFocusInWindow();
                    JOptionPane.showMessageDialog(
                        null,
                        "Valeur inattendue : " + coinInputField.getText(),
                        "Erreur !",
                        JOptionPane.INFORMATION_MESSAGE
                    );
                }

            }
        });

        cancelButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                model.cancelCredit();
            }
        });

        consumeButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                model.takeChange();
                model.takeDrink();
            }
        });
    }

    private void refresh() {

        if (model.canGetChange()) {
            changeInformation.setText("Cet appareil rend la monnaie");
        } else {
            changeInformation.setText("Cet appareil ne rend pas la monnaie");
        }

        creditInformation.setText("Vous disposez d'un crédit de "
                    + model.getCreditAmount() + " cents");

        DrinkTypes d = model.getLastDrink();
        if (d != null) {
            drinkOutputField.setText(model.getLastDrink().toString());
            changeOutputField.setText(String.valueOf(model.getChangeAmount()));
        } else {
            drinkOutputField.setText("");
            changeOutputField.setText("");
        }

        for (JButton b:drinksButtons.keySet()) {
            if (model.getDrinkNb(drinksButtons.get(b)) > 0) {
                b.setEnabled(true);
            } else {
                b.setEnabled(false);
            }
        }
    }

    // POINT D'ENTREE

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new DrinksMachine().display();
            }
        });
    }
}
