package serie06;

import util.Contract;

public class StdDrinksMachineModel implements DrinksMachineModel {

    // ATTRIBUTS

    private DrinkTypes lastDrink;
    private StdStock<DrinkTypes> drinkStock;
    private StdMoneyAmount cashBox;
    private StdMoneyAmount creditBox;
    private StdMoneyAmount changeBox;

    // CONSTRUCTEURS

    public StdDrinksMachineModel() {
        drinkStock = new StdStock<DrinkTypes>();
        for (DrinkTypes d:DrinkTypes.values()) {
            drinkStock.addElement(d, MAX_DRINK);
        }
        cashBox = new StdMoneyAmount();
        creditBox = new StdMoneyAmount();
        changeBox = new StdMoneyAmount();
        lastDrink = null;
    }

    // REQUETES

    @Override
    public int getDrinkNb(DrinkTypes d) {
        Contract.checkCondition(d != null);

        return drinkStock.getNumber(d);
    }

    @Override
    public DrinkTypes getLastDrink() {
        return lastDrink;
    }

    @Override
    public int getCreditAmount() {
        return creditBox.getTotalValue();
    }

    @Override
    public int getCreditNb(CoinTypes c) {
        Contract.checkCondition(c != null);

        return creditBox.getNumber(c);
    }

    @Override
    public int getCashAmount() {
        return cashBox.getTotalValue();
    }

    @Override
    public int getCashNb(CoinTypes c) {
        Contract.checkCondition(c != null);

        return cashBox.getNumber(c);
    }

    @Override
    public int getChangeAmount() {
        return changeBox.getTotalValue();
    }

    @Override
    public int getChangeNb(CoinTypes c) {
        Contract.checkCondition(c != null);

        return changeBox.getNumber(c);
    }

    @Override
    public boolean canGetChange() {
        int maxValueCoin = 1;
        for (CoinTypes c:CoinTypes.values()) {
            if (maxValueCoin < c.getFaceValue()) {
                maxValueCoin = c.getFaceValue();
            }
        }
        for (int i = 1; i < maxValueCoin; i++) {
            if (cashBox.computeChange(i) == null) {
                return false;
            }
        }
        return true;
    }

    // COMMANDES

    @Override
    public void selectDrink(DrinkTypes d) {
        Contract.checkCondition(d != null);
        Contract.checkCondition(getDrinkNb(d) >= 1);
        Contract.checkCondition(getCreditAmount() >= d.getPrice());
        Contract.checkCondition(getLastDrink() == null);

        boolean changeIsOK = canGetChange();
        cashBox.addAmount(creditBox);
        drinkStock.removeElement(d);
        int value = creditBox.getTotalValue();
        if (value > d.getPrice() && changeIsOK) {
            MoneyAmount ma = cashBox.computeChange(value - d.getPrice());
            changeBox.addAmount(ma);
            cashBox.removeAmount(ma);
        }
        creditBox = new StdMoneyAmount();
        lastDrink = d;
    }

    @Override
    public void fillStock(DrinkTypes d, int q) {
        Contract.checkCondition(d != null);
        Contract.checkCondition(q > 0 && getDrinkNb(d) + q <= MAX_DRINK);

        drinkStock.addElement(d, q);
    }

    @Override
    public void fillCash(CoinTypes c, int q) {
        Contract.checkCondition(c != null);
        Contract.checkCondition(q > 0
                && getCashNb(c) + getCreditNb(c) + q <= MAX_COIN);

        cashBox.addElement(c, q);
    }

    @Override
    public void insertCoin(CoinTypes c) {
        Contract.checkCondition(c != null);

        if (getCashNb(c) + getCreditNb(c) == MAX_COIN) {
            changeBox.addElement(c);
        } else {
            creditBox.addElement(c);
        }
    }

    @Override
    public void cancelCredit() {
        changeBox.addAmount(creditBox);
        creditBox = new StdMoneyAmount();
    }

    @Override
    public void takeDrink() {
        lastDrink = null;
    }

    @Override
    public void takeChange() {
        changeBox = new StdMoneyAmount();
    }

    @Override
    public void reset() {
        drinkStock = new StdStock<DrinkTypes>();
        cashBox = new StdMoneyAmount();
        creditBox = new StdMoneyAmount();
        changeBox = new StdMoneyAmount();
        lastDrink = null;
    }

}
