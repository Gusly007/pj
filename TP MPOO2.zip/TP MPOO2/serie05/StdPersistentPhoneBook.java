package serie05;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;

import serie04.Civ;
import serie04.Contact;
import serie04.StdContact;
import serie04.StdPhoneBook;
import util.Contract;

public class StdPersistentPhoneBook extends StdPhoneBook
    implements PersistentPhoneBook {

    // ATTRIBUTS

    private File file;

    // CONSTRUCTEURS

    public StdPersistentPhoneBook(File file) {
        this.file = file;
    }

    public StdPersistentPhoneBook() {
        this(null);
    }

    // REQUETES

    @Override
    public File getFile() {
        return file;
    }

    // COMMANDES

    @Override
    public void setFile(File file) {
        Contract.checkCondition(file != null);

        this.file = file;
    }

    @Override
    public void load() throws IOException, BadSyntaxException {
        Contract.checkCondition(getFile() != null);

        clear();
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String line = reader.readLine();
            while (line != null) {
                Matcher m = LINE_RECOGNIZER.matcher(line);
                if (!m.matches()) {
                    throw new BadSyntaxException();
                }

                String[] collect = line.split(":");
                Contact c = new StdContact(
                        Civ.values()[Integer.valueOf(collect[0].trim())],
                        collect[1].trim(), collect[2].trim());
                for (String nb: collect[3].split(",")) {
                    addPhoneNumber(c, nb.trim());
                }
                line = reader.readLine();
            }
        } catch (java.io.FileNotFoundException e) {
            clear();
            throw e;
        } catch (IOException e) {
            clear();
            throw e;
        } catch (BadSyntaxException e) {
            clear();
            throw e;
        } finally {
            if (reader != null) {
                reader.close();
            }
        }

    }

    @Override
    public void save() throws IOException {
        Contract.checkCondition(getFile() != null);

        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(file));
            for (Contact c:contacts()) {
                String line = c.getCivility().ordinal() + ":"
                        + c.getLastName() + ":"
                        + c.getFirstName() + ":";
                for (String nb:phoneNumbers(c)) {
                    if (firstPhoneNumber(c).equals(nb)) {
                        line += nb;
                    } else {
                        line += "," + nb;
                    }
                }
                writer.write(line);
                writer.newLine();
            }
        } catch (java.io.FileNotFoundException e) {
            throw e;
        } catch (IOException e) {
            throw e;
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }
}
