package serie11;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.EtchedBorder;

import serie11.model.PetException;
import serie11.model.State;
import serie11.model.StdPetModel;

public class Pet {

    // ATTRIBUTS

    private JFrame mainFrame;
    private StdPetModel model;
    private JLabel stateBar;
    private JTextArea textZone;
    private JScrollPane scroll;
    private Map<Menu, JMenuItem[]> jItems;
    private Map<Item, JMenuItem> jItemFromItem;
    private Map<JMenuItem, Item> items;


    // CONSTRUCTEURS

    public Pet() {
        createModel();
        createView();
        placeComponents();
        createController();
    }

    // COMMANDES

    /**
     * Rend l'application visible au centre de l'écran.
     */
    public void display() {
        refresh();
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    private void createModel() {
        model = new StdPetModel();
    }

    private void createView() {
        final int width = 440;
        final int height = 600;
        mainFrame = new JFrame("Petit Editeur de Texte");
        mainFrame.setPreferredSize(new Dimension(width, height));

        stateBar = new JLabel();

        textZone = new JTextArea();
        textZone.setBackground(Color.BLACK);
        textZone.setForeground(Color.WHITE);
        textZone.setCaretColor(Color.WHITE);

        jItems = new HashMap<Menu, JMenuItem[]>();
        items = new HashMap<JMenuItem, Item>();
        jItemFromItem = new HashMap<Item, JMenuItem>();
        for (Menu m:Menu.values()) {
            Item[] listItems = Menu.MENU_STRUCT.get(m);
            JMenuItem[] list = new JMenuItem[listItems.length];
            for (int i = 0; i < listItems.length; i++) {
                if (listItems[i] != null) {
                    list[i] = new JMenuItem(listItems[i].getLabel());
                    items.put(list[i], listItems[i]);
                    jItemFromItem.put(listItems[i], list[i]);
                } else {
                    list[i] = null;
                }
            }
            jItems.put(m, list);
        }

        scroll = new JScrollPane();
    }

    private void placeComponents() {
        JMenuBar menuBar = new JMenuBar();
        for (Menu m:Menu.values()) {
            JMenu menu = new JMenu(m.getLabel());
            for (JMenuItem i:jItems.get(m)) {
                if (i == null) {
                    menu.addSeparator();
                } else {
                    menu.add(i);
                }
            }
            menuBar.add(menu);
        }
        mainFrame.add(menuBar, BorderLayout.NORTH);

        mainFrame.add(scroll, BorderLayout.CENTER);

        JPanel p = new JPanel(); {
            p.setLayout(new FlowLayout(FlowLayout.LEFT));
            p.add(stateBar);
        }
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEtchedBorder(EtchedBorder.RAISED),
                BorderFactory.createEmptyBorder(3, 5, 3, 5)));
        mainFrame.add(p, BorderLayout.SOUTH);
    }

    private void createController() {
        mainFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        mainFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (confirmAction()) {
                    System.exit(0);
                }
            }
        });

        model.addObserver(new Observer() {
            @Override
            public void update(Observable o, Object arg) {
                refresh();
            }
        });

        jItemFromItem.get(Item.CLEAR).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (confirmAction()) {
                    model.clearDoc();
                }
            }
        });

        jItemFromItem.get(Item.CLOSE).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (confirmAction()) {
                    model.removeDocAndFile();
                }
            }
        });

        jItemFromItem.get(Item.NEW).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (confirmAction()) {
                    model.setNewDocWithoutFile();
                }
            }
        });

        jItemFromItem.get(Item.NEW_FROM_FILE).addActionListener(
                new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (confirmAction()) {
                    JFileChooser chooser = new JFileChooser();
                    if (chooser.showOpenDialog(mainFrame)
                            == JFileChooser.APPROVE_OPTION) {
                        try {
                            File f = chooser.getSelectedFile();
                            if (f.isFile() && f.canRead() && f.canWrite()) {
                                model.setNewDocFromFile(
                                        chooser.getSelectedFile());
                            } else {
                                throw new PetException();
                            }
                        } catch (PetException e1) {
                            JOptionPane.showMessageDialog(
                                null,
                                e1.getMessage(),
                                "Erreur !",
                                JOptionPane.ERROR_MESSAGE
                            );
                        }
                    }
                }
            }
        });

        jItemFromItem.get(Item.OPEN).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (confirmAction()) {
                    JFileChooser chooser = new JFileChooser();
                    if (chooser.showOpenDialog(mainFrame)
                            == JFileChooser.APPROVE_OPTION) {
                        try {
                            File f = chooser.getSelectedFile();
                            if (f.isFile() && f.canRead() && f.canWrite()) {
                                model.setNewDocAndNewFile(f);
                            } else {
                                throw new PetException("Impossible d'ouvrir ce"
                                        + " fichier");
                            }
                        } catch (PetException e1) {
                            JOptionPane.showMessageDialog(
                                null,
                                e1.getMessage(),
                                "Erreur !",
                                JOptionPane.ERROR_MESSAGE
                            );
                        }
                    }
                }
            }
        });

        jItemFromItem.get(Item.QUIT).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (confirmAction()) {
                    System.exit(0);
                }
            }
        });

        jItemFromItem.get(Item.REOPEN).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (confirmAction()) {
                    try {
                        model.resetCurrentDocWithCurrentFile();
                        textZone.setCaretPosition(0);
                    } catch (PetException e1) {
                        JOptionPane.showMessageDialog(
                            null,
                            e1.getMessage(),
                            "Erreur !",
                            JOptionPane.ERROR_MESSAGE
                        );
                    }
                }
            }
        });

        jItemFromItem.get(Item.SAVE).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    model.saveCurrentDocIntoCurrentFile();
                } catch (PetException e1) {
                    JOptionPane.showMessageDialog(
                        null,
                        e1.getMessage(),
                        "Erreur !",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        });

        jItemFromItem.get(Item.SAVE_AS).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                if (chooser.showSaveDialog(mainFrame)
                        == JFileChooser.APPROVE_OPTION) {
                    try {
                        File f = chooser.getSelectedFile();
                        f.createNewFile();
                        if (!f.exists()) {
                            throw new IOException();
                        }
                        if (f.isFile() && f.canRead() && f.canWrite()) {
                            model.saveCurrentDocIntoFile(
                                    chooser.getSelectedFile());
                        } else {
                            throw new PetException();
                        }
                    } catch (Exception e1) {
                        JOptionPane.showMessageDialog(
                            null,
                            e1.getMessage(),
                            "Erreur !",
                            JOptionPane.ERROR_MESSAGE
                        );
                    }
                }
            }
        });
    }

    private void refresh() {
        jItemFromItem.get(Item.CLEAR).setEnabled(model.getDocument() != null
                && model.getDocument().getLength() > 0);

        jItemFromItem.get(Item.SAVE).setEnabled(
                model.getState() == State.FIL_DOC && !model.isSynchronized());

        jItemFromItem.get(Item.REOPEN).setEnabled(
                model.getState() == State.FIL_DOC && !model.isSynchronized());

        jItemFromItem.get(Item.SAVE_AS).setEnabled(model.getDocument() != null);

        jItemFromItem.get(Item.CLOSE).setEnabled(model.getDocument() != null);

        if (model.getDocument() == null) {
            scroll.setViewportView(null);
        } else if (textZone.getDocument() != model.getDocument()) {
            textZone.setDocument(model.getDocument());
            scroll.setViewportView(textZone);
        }

        String text = "Fichier : ";
        if (model.getState() == State.NOF_DOC
                || (!model.isSynchronized()
                        && model.getState() == State.FIL_DOC)) {
            text += "* ";
        }
        if (model.getFile() != null) {
            text += "<" + model.getFile().getAbsolutePath() + ">";
        } else {
            text += "<aucun>";
        }
        stateBar.setText(text);
    }

    // OUTILS

    /**
     * Propose de sauvegarder le travail en cours, si nécessaire, avant
     *  de poursuivre l'action demandée.
     * Retourne true (= confirmation de poursuite) si et seulement si :
     *    - le modèle est synchronisé,
     *    - ou il n'y a pas de document dans le modèle,
     *    - ou le document est en cours d'édition et l'utilisateur
     *          ne veut pas sauvegarder son travail.
     */
    private boolean confirmAction() {
        if (model.isSynchronized() || model.getDocument() == null) {
            return true;
        }
        if (JOptionPane.showConfirmDialog(
            null,
            "Attention document non sauvegardé\n"
            + "Voulez-vous vraiment perdre vos données ?",
            "Erreur !",
            JOptionPane.YES_NO_OPTION
        ) == JOptionPane.YES_OPTION) {
            return true;
        }
        return false;
    }

    // POINT D'ENTREE

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Pet().display();
            }
        });
    }
}
