package serie11.model;

import java.io.File;
import java.io.IOException;
import java.util.Observable;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;

import util.Contract;

public class StdPetModel extends Observable implements PetModel {

    // ATTRIBUTS

    private FilDocManager manager;
    private boolean isSynchronized;

    // CONSTRUCTEURS

    public StdPetModel() {
        manager = new StdFilDocManager();
    }

    // REQUETES

    @Override
    public Document getDocument() {
        return manager.getDocument();
    }

    @Override
    public File getFile() {
        return manager.getFile();
    }

    @Override
    public State getState() {
        return manager.getState();
    }

    @Override
    public boolean isSynchronized() {
        return isSynchronized;
    }

    // COMMANDES

    @Override
    public void clearDoc() {
        Contract.checkCondition(getDocument() != null, "clearDoc :"
                + " document null");

        manager.setDocument(new PlainDocument());
        isSynchronized = false;
        addListener();
        setChanged();
        notifyObservers();
    }

    @Override
    public void removeDocAndFile() {
        Contract.checkCondition(getDocument() != null, "removeDocAndFile :"
                + " document null");

        manager.removeDocument();
        manager.removeFile();
        isSynchronized = false;
        setChanged();
        notifyObservers();
    }

    @Override
    public void resetCurrentDocWithCurrentFile() throws PetException {
        Contract.checkCondition(getState() == State.FIL_DOC,
                "resetCurrentDocWithCurrentFile : state != FIL_DOC");
        Contract.checkCondition(!isSynchronized(),
                "resetCurrentDocWithCurrentFile : isSynchronized() == true");

        try {
            manager.load();
        } catch (IOException e) {
            throw new PetException("IOException");
        } catch (BadLocationException e) {
            throw new PetException("BadLocationException");
        }
        isSynchronized = true;
        setChanged();
        notifyObservers();
    }

    @Override
    public void saveCurrentDocIntoCurrentFile() throws PetException {
        Contract.checkCondition(getState() == State.FIL_DOC,
                "saveCurrentDocIntoCurrentFile : state != FIL_DOC");
        Contract.checkCondition(!isSynchronized(),
                "saveCurrentDocIntoCurrentFile : isSynchronized() == true");

        try {
            manager.save();
        } catch (IOException e) {
            throw new PetException("IOException");
        } catch (BadLocationException e) {
            throw new PetException("BadLocationException");
        }
        isSynchronized = true;
        setChanged();
        notifyObservers();
    }

    @Override
    public void saveCurrentDocIntoFile(File f) throws PetException {
        Contract.checkCondition(getDocument() != null,
                "saveCurrentDocIntoFile : document null");
        Contract.checkCondition(f != null
                && f.isFile() && f.canRead() && f.canWrite(),
                "saveCurrentDocIntoFile : bad file");

        manager.setFile(f);
        try {
            manager.save();
        } catch (IOException e) {
            throw new PetException("IOException");
        } catch (BadLocationException e) {
            throw new PetException("BadLocationException");
        }
        isSynchronized = true;
        setChanged();
        notifyObservers();
    }

    @Override
    public void setNewDocAndNewFile(File f) throws PetException {
        Contract.checkCondition(f != null
                && f.isFile() && f.canRead() && f.canWrite(),
                "setNewDocAndNewFile : bad file");

        File file = manager.getFile();
        Document doc = manager.getDocument();
        manager.setFile(f);
        manager.setDocument(new PlainDocument());
        try {
            manager.load();
        } catch (IOException e) {
            if (file != null) {
                manager.setFile(file);
            } else {
                manager.removeFile();
            }
            if (doc != null) {
                manager.setDocument(doc);
            } else {
                manager.getDocument();
            }
            throw new PetException("IOException");
        } catch (BadLocationException e) {
            throw new PetException("BadLocationException");
        }
        isSynchronized = true;
        addListener();
        setChanged();
        notifyObservers();
    }

    @Override
    public void setNewDocFromFile(File f) throws PetException {
        Contract.checkCondition(f != null
                && f.isFile() && f.canRead() && f.canWrite(),
                "setNewDocFromFile : bad file");

        setNewDocAndNewFile(f);
        manager.removeFile();
        isSynchronized = false;
        setChanged();
        notifyObservers();
    }

    @Override
    public void setNewDocWithoutFile() {
        manager.removeFile();
        manager.setDocument(new PlainDocument());
        isSynchronized = false;
        addListener();
        setChanged();
        notifyObservers();
    }

    // OUTILS

    private void addListener() {
        getDocument().addDocumentListener(new DocumentListener() {

            @Override
            public void removeUpdate(DocumentEvent e) {
                if (isSynchronized) {
                    isSynchronized = false;
                }
                setChanged();
                notifyObservers();
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                if (isSynchronized) {
                    isSynchronized = false;
                }
                setChanged();
                notifyObservers();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
           }
        });
    }
}
