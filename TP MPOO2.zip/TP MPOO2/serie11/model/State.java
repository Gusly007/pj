package serie11.model;

public enum State {
    NOF_NOD, NOF_DOC, FIL_NOD, FIL_DOC;
}
