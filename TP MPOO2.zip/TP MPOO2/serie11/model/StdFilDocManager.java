package serie11.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

import util.Contract;

public class StdFilDocManager implements FilDocManager {

    // ATTRIBUTS

    private Document document;
    private File file;

    // CONSTRUCTEURS

    public StdFilDocManager() {
        document = null;
        file = null;
    }

    // REQUETES

    @Override
    public Document getDocument() {
        return document;
    }

    @Override
    public File getFile() {
        return file;
    }

    @Override
    public State getState() {
        if (getFile() == null  &&  getDocument() == null) {
            return State.NOF_NOD;
        } else if (getFile() == null  &&  getDocument() != null) {
            return State.NOF_DOC;
        } else if (getFile() != null  &&  getDocument() == null) {
            return State.FIL_NOD;
        } else {
            return State.FIL_DOC;
        }
    }

    // COMMANDES

    @Override
    public void load() throws IOException, BadLocationException {
        Contract.checkCondition(getState() == State.FIL_DOC);

        document.remove(0, document.getLength());
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            int offset = 0;
            while ((line = reader.readLine()) != null) {
                document.insertString(offset, line, null);
                offset += line.length();
                if (offset != file.length()) {
                    document.insertString(offset, "\n", null);
                    offset++;
                }
            }
            reader.close();
        } catch (IOException e) {
            throw e;
        } catch (BadLocationException e) {
            throw e;
        }
    }

    @Override
    public void removeDocument() {
        document = null;
    }

    @Override
    public void removeFile() {
        file = null;
    }

    @Override
    public void save() throws IOException, BadLocationException {
        Contract.checkCondition(getState() == State.FIL_DOC);

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(document.getText(0, document.getLength()));
            writer.close();
        } catch (IOException e) {
            throw e;
        } catch (BadLocationException e) {
            throw e;
        }
    }

    @Override
    public void setDocument(Document d) {
        Contract.checkCondition(d != null);

        document = d;
    }

    @Override
    public void setFile(File f) {
        Contract.checkCondition(f != null
                && f.isFile() && f.canRead() && f.canWrite());

        file = f;
    }

}
