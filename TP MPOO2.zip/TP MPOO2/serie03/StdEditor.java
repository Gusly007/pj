package serie03;

import serie03.cmd.Clear;
import serie03.cmd.Command;
import serie03.cmd.DeleteLine;
import serie03.cmd.InsertLine;
import util.Contract;

public class StdEditor implements Editor {

    // ATTRIBUTS

    private Text text;
    private History<Command> history;

    // CONSTRUCTEURS

    public StdEditor() {
        text = new StdText();
        history = new StdHistory<Command>(DEFAULT_HISTORY_SIZE);
    }

    public StdEditor(int historySize) {
        Contract.checkCondition(historySize > 0,
                "StdEditor : Taille d'historique incorrect");

        text = new StdText();
        history = new StdHistory<Command>(historySize);
    }

    // REQUETES

    @Override
    public int getTextLinesNb() {
        return text.getLinesNb();
    }

    @Override
    public String getTextContent() {
        return text.getContent();
    }

    @Override
    public int getHistorySize() {
        return history.getMaxHeight();
    }

    @Override
    public int nbOfPossibleUndo() {
        return history.getCurrentPosition();
    }

    @Override
    public int nbOfPossibleRedo() {
        return history.getEndPosition() - history.getCurrentPosition();
    }

    // COMMANDES

    @Override
    public void clear() {
        Command c = new Clear(text);
        c.act();
        history.add(c);
    }

    @Override
    public void insertLine(int numLine, String s) {
        Contract.checkCondition(s != null, "insertLine : s == null");
        Contract.checkCondition(1 <= numLine
                && numLine <= getTextLinesNb() + 1,
                "insertLine : nb de lignes incorrect");

        Command c = new InsertLine(text, numLine, s);
        c.act();
        history.add(c);
    }

    @Override
    public void deleteLine(int numLine) {
        Contract.checkCondition(1 <= numLine && numLine <= getTextLinesNb(),
                "deleteLine : nb de lignes incorrect");

        Command c = new DeleteLine(text, numLine);
        c.act();
        history.add(c);
    }

    @Override
    public void redo() {
        Contract.checkCondition(nbOfPossibleRedo() > 0,
                "redo : impossible de redo");

        history.goForward();
        history.getCurrentElement().act();
    }

    @Override
    public void undo() {
        Contract.checkCondition(nbOfPossibleUndo() > 0,
                "redo : impossible de undo");

        history.getCurrentElement().act();
        history.goBackward();
    }
}
