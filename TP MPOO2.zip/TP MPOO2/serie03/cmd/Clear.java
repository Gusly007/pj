package serie03.cmd;

import java.util.ArrayList;
import java.util.List;

import serie03.Text;

/**
 * @inv <pre>
 *     getBackup() != null </pre>
 */
public class Clear extends AbstractCommand {
    
    // ATTRIBUTS
    
    private List<String> backup;
    
    // CONSTRUCTEURS
    
    /**
     * Une commande de vidage du texte.
     * @pre <pre>
     *     text != null </pre>
     * @post <pre>
     *     getText() == text
     *     getState() == State.DO
     *     getBackup().size() == 0 </pre>
     */
    public Clear(Text text) {
        super(text);
        backup = new ArrayList<String>();
    }
    
    // REQUETES
    
    /**
     * La liste des lignes composant le texte juste avant d'exécuter undoIt.
     */
    List<String> getBackup() {
        return backup;
    }
    
    // COMMANDES

    /**
     * Efface la totalité du texte.
     * @post <pre>
     *     getBackup().size() == old getText().getLinesNb()
     *     forall i:[0..getBackup().size()[ :
     *         getBackup().get(i).equals(old getText().getLine(i+1))
     *     getText().getLinesNb() == 0 </pre>
     */
    @Override
    protected void doIt() {
        int length = getText().getLinesNb();
        for (int i = 0; i < length; i++) {
            getBackup().add(getText().getLine(i + 1));
        }
        getText().clear();
    }
    
    /**
     * Régénère la totalité du texte.
     * @post <pre>
     *     getText().getLinesNb() == getBackup().size()
     *     forall i:[0..getText().getLinesNb()[ :
     *         getText().getLine(i+1).equals(getBackup().get(i)) </pre>
     */
    @Override
    protected void undoIt() {
        for (int i = 0; i < getBackup().size(); i++) {
            getText().insertLine(i + 1, getBackup().get(i));
        }
        backup = new ArrayList<String>();
    }
}

