package serie03.cmd;

import serie03.Text;
import util.Contract;

/**
 * @inv <pre>
 *     1 <= getIndex()
 *     getLine() != null
 *     canDo() ==> getIndex() <= getText().getLinesNb() + 1
 *     canUndo() ==> getIndex() <= getText().getLinesNb() </pre>
 */
public class InsertLine extends AbstractCommand {

    // ATTRIBUTS
    
    private final int index;
    
    private String line;
    
    // CONSTRUCTEURS
    
    /**
     * Une commande d'insertion de la chaîne <code>line</code> en
     *  position <code>index</code> dans <code>text</code>.
     * @pre <pre>
     *     text != null
     *     line != null
     *     1 <= numLine </pre>
     * @post <pre>
     *     getText() == text
     *     getIndex() == numLine
     *     getLine().equals(line)
     *     getState() == State.DO </pre>
     */
    public InsertLine(Text text, int numLine, String line) {
        super(text);
        Contract.checkCondition(line != null);
        Contract.checkCondition(numLine >= 1,
                "le numéro de ligne n'est pas valide (" + numLine + ")");
        
        index = numLine;
        this.line = line;
    }
    
    // REQUETES
    
    @Override
    public boolean canDo() {
        return
            super.canDo()
            && line != null
            && index <= getText().getLinesNb() + 1;
    }
    
    @Override
    public boolean canUndo() {
        return
            super.canUndo()
            && index <= getText().getLinesNb();
    }
    
    /**
     * Le rang où l'on doit insérer la ligne dans le texte.
     */
    int getIndex() {
        return index;
    }
    
    /**
     * La ligne à insérer.
     */
    String getLine() {
        return line;
    }
    
    // COMMANDES
    
    /**
     * Exécute l'insertion de la chaîne dans le texte.
     * @post <pre>
     *     getText().getLinesNb() == old getText().getLinesNb() + 1
     *     getText().getLine(getIndex()).equals(getLine())
     *     forall i:[getIndex() + 1..getText().getLinesNb()] :
     *         getText().getLine(i).equals(old getText().getLine(i - 1)) </pre>
     */
    @Override
    protected void doIt() {
        getText().insertLine(index, line);
    }
    
    /**
     * Annule l'insertion de la chaîne dans le texte.
     * @post <pre>
     *     getText().getLinesNb() == old getText().getLinesNb() - 1
     *     forall i:[getIndex()..getText().getLinesNb()] :
     *         getText().getLine(i).equals(old getText().getLine(i + 1)) </pre>
     */
    @Override
    protected void undoIt() {
        getText().deleteLine(index);
    }
}

