package serie03;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.Deque;
import java.util.Queue;

import util.Contract;

public final class StdHistory<E> implements History<E> {

    // ATTRIBUTS

    private int maxHeight;
    private int currentPosition;
    private int endPosition;
    private Deque<E> head;
    private Queue<E> tail;

    // CONSTRUCTEURS

    public StdHistory(int maxHeight) {
        Contract.checkCondition(maxHeight > 0);

        this.maxHeight = maxHeight;
        currentPosition = 0;
        endPosition = 0;
        head = new ArrayDeque<E>();
        tail = Collections.asLifoQueue(new ArrayDeque<E>());
    }

    // REQUETES

    @Override
    public int getMaxHeight() {
        return maxHeight;
    }

    @Override
    public int getCurrentPosition() {
        return currentPosition;
    }

    @Override
    public E getCurrentElement() {
        Contract.checkCondition(getCurrentPosition() > 0);

        return head.element();
    }

    @Override
    public int getEndPosition() {
        return endPosition;
    }

    // COMMANDES

    @Override
    public void add(E e) {
        Contract.checkCondition(e != null);

        if (getCurrentPosition() == getMaxHeight()) {
            head.removeLast();
        } else {
            currentPosition++;
        }
        head.addFirst(e);
        tail = Collections.asLifoQueue(new ArrayDeque<E>());
        endPosition = currentPosition;
    }

    @Override
    public void goForward() {
        Contract.checkCondition(getCurrentPosition() < getEndPosition());

        head.addFirst(tail.remove());
        currentPosition++;
    }

    @Override
    public void goBackward() {
        Contract.checkCondition(getCurrentPosition() > 0);

        tail.add(head.remove());
        currentPosition--;
    }
}
