package serie04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.TreeMap;

import util.Contract;

public class StdPhoneBook implements PhoneBook {

    // ATTRIBUTS

    private NavigableMap<Contact, List<String>> data;

    // CONSTRUCTEURS

    public StdPhoneBook() {
        data = new TreeMap<Contact, List<String>>();
    }

    // REQUETES

    @Override
    public String firstPhoneNumber(Contact p) {
        return phoneNumbers(p).get(0);
    }

    @Override
    public List<String> phoneNumbers(Contact p) {
        Contract.checkCondition((p != null) && contains(p));

        return Collections.unmodifiableList(data.get(p));
    }

    @Override
    public NavigableSet<Contact> contacts() {
        return data.navigableKeySet();
    }

    @Override
    public boolean contains(Contact p) {
        Contract.checkCondition(p != null);

        return data.containsKey(p);
    }

    @Override
    public boolean isEmpty() {
        return data.isEmpty();
    }

    // COMMANDES

    @Override
    public void addEntry(Contact p, List<String> nums) {
        Contract.checkCondition((p != null) && !contains(p));
        Contract.checkCondition((nums != null) && (nums.size() > 0));

        List<String> list = new ArrayList<String>();
        for (int i = 0; i < nums.size(); i++) {
            String n = nums.get(i);
            if (!list.contains(n)) {
                list.add(n);
            }
        }
        data.put(p, list);
    }

    @Override
    public void addPhoneNumber(Contact p, String n) {
        Contract.checkCondition(p != null);
        Contract.checkCondition((n != null) && !n.equals(""));

        List<String> list = new ArrayList<String>();
        if (!data.containsKey(p)) {
            list.add(n);
        } else {
            list = data.get(p);
            if (!list.contains(n)) {
                list.add(n);
            }
        }
        data.put(p, list);
    }

    @Override
    public void removeEntry(Contact p) {
        Contract.checkCondition((p != null) && contains(p));

        data.remove(p);
    }

    @Override
    public void deletePhoneNumber(Contact p, String n) {
        Contract.checkCondition((p != null) && contains(p));
        Contract.checkCondition((n != null) && !n.equals(""));

        List<String> list = data.get(p);
        if (list.contains(n)) {
            if (list.size() == 1) {
                removeEntry(p);
            } else {
                list.remove(n);
            }
        }
    }

    @Override
    public void clear() {
        data.clear();
    }
}
