package serie04;

import java.util.EnumSet;

import util.Contract;

public enum Civ {
    UKN(""),
    MR("M."),
    MRS("Mme"),
    MS("Mlle");
    
    static {
        UKN.candidates = EnumSet.of(MR, MRS, MS);
        MR.candidates = EnumSet.noneOf(Civ.class);
        MRS.candidates = EnumSet.of(MS);
        MS.candidates = EnumSet.of(MRS);
    }
    
    private final String name;
    private EnumSet<Civ> candidates;
    
    Civ(String name) {
        this.name = name;
    }
    
    /**
     * @pre
     *     candidate != null
     * @post
     *     this == UKN ==> result == { MR, MRS, MS }.contains(candidate)
     *     this == MR  ==> result == false
     *     this == MRS ==> result == (candidate == MS)
     *     this == MS  ==> result == (candidate == MRS)
     */
    public boolean canEvolveTo(Civ candidate) {
        Contract.checkCondition(candidate != null);
        return this.candidates.contains(candidate);
    }
    /**
     * @post
     *     this == UKN ==> result.equals("")
     *     this == MR  ==> result.equals("M.")
     *     this == MRS ==> result.equals("Mme")
     *     this == MS  ==> result.equals("Mlle")
     */
    public String toString() {
        return this.name;
    }
}
