package serie08;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;

import serie08.SpeedometerModel.SpeedUnit;

public class Speedometer {

    // ATTRIBUTS

    private JFrame mainFrame;
    private GraphicSpeedometer g;
    private Map<JRadioButton, SpeedUnit> unitsButtons;
    private Map<SpeedUnit, JRadioButton> buttonsUnits;
    private JButton slowDown;
    private JButton speedUp;
    private JButton power;
    private SpeedometerModel model;

    // CONSTRUCTEURS

    public Speedometer() {
        createModel();
        createView();
        placeComponents();
        createController();
    }

    // COMMANDES

    /**
     * Rend l'application visible au centre de l'écran.
     */
    public void display() {
        refresh();
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    // OUTILS

    private void createModel() {
        final double maxSpeed = 100;
        final double step = 5;
        model = new StdSpeedometerModel(step, maxSpeed);
    }

    private void createView() {

        mainFrame = new JFrame("Speedometer");

        unitsButtons = new HashMap<JRadioButton, SpeedUnit>();
        buttonsUnits = new EnumMap<SpeedUnit, JRadioButton>(SpeedUnit.class);
        for (SpeedUnit u:SpeedUnit.values()) {
            JRadioButton b = new JRadioButton(u.toString());
            unitsButtons.put(b, u);
            buttonsUnits.put(u, b);
        }

        slowDown = new JButton("-");
        slowDown.setEnabled(false);

        speedUp = new JButton("+");
        slowDown.setEnabled(false);

        power = new JButton("Turn ON");

        g = new GraphicSpeedometer(model);
    }

    private void placeComponents() {
        JPanel p = new JPanel(); {
            p.setLayout(new GridLayout(0, 1));
            JPanel q = new JPanel(); {
                q.setLayout(new FlowLayout(FlowLayout.CENTER));
                JPanel r = new JPanel(); {
                    r.setLayout(new GridLayout(0, 1));
                    r.setBorder(BorderFactory.createEtchedBorder());
                    for (SpeedUnit u:SpeedUnit.values()) {
                        r.add(buttonsUnits.get(u));
                    }
                }
                q.add(r);
            }
            p.add(q);
            q = new JPanel(); {
                q.setLayout(new FlowLayout(FlowLayout.CENTER));
                JPanel r = new JPanel(); {
                    r.setLayout(new GridLayout(1, 0));
                    r.add(slowDown);
                    r.add(speedUp);
                }
                q.add(r);
            }
            p.add(q);
            q = new JPanel(); {
                q.setLayout(new FlowLayout(FlowLayout.CENTER));
                q.add(power);
            }
            p.add(q);
        }
        mainFrame.add(p, BorderLayout.WEST);
        mainFrame.add(g, BorderLayout.CENTER);
    }

    private void createController() {
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        model.addObserver(new Observer() {
            @Override
            public void update(Observable o, Object arg) {
                refresh();
            }
        });

        ActionListener a = new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setUnit(unitsButtons.get(e.getSource()));
            }
        };
        
        for (JRadioButton b:unitsButtons.keySet()) {
            b.addActionListener(a);
        }

        slowDown.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (model.isOn()) {
                    model.slowDown();
                }
            }
        });

        speedUp.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (model.isOn()) {
                    model.speedUp();
                }
            }
        });

        power.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (model.isOn()) {
                    model.turnOff();
                } else {
                    model.turnOn();
                }
            }
        });

        ButtonGroup group = new ButtonGroup();
        for (JRadioButton b:unitsButtons.keySet()) {
            group.add(b);
        }
    }

    private void refresh() {
        if (!model.isOn()) {
            power.setText("Turn OFF");
            slowDown.setEnabled(false);
            speedUp.setEnabled(false);
        } else {
            power.setText("Turn ON");
            if (model.getSpeed() == 0) {
                slowDown.setEnabled(false);
            } else {
                slowDown.setEnabled(true);
            }
            if (model.getSpeed() == model.getMaxSpeed()) {
                speedUp.setEnabled(false);
            } else {
                speedUp.setEnabled(true);
            }
        }
        buttonsUnits.get(model.getUnit()).setSelected(true);
    }

    // POINT D'ENTREE

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Speedometer().display();
            }
        });
    }
}
