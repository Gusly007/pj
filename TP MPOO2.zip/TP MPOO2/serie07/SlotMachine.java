package serie07;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class SlotMachine {

    // ATTRIBUTS
    
    private JFrame mainFrame;
    private JButton tryButton;
    private SlotModel model;
    private JTextField result;
    private JLabel won;
    private JLabel lost;
    private JLabel payout;

    // CONSTRUCTEURS
    
    public SlotMachine() {
        createModel();
        createView();
        placeComponents();
        createController();
    }
    
    // COMMANDES
    
    /**
     * Rend l'application visible au centre de l'écran.
     */
    public void display() {
        refresh();
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    // OUTILS
    
    private void createModel() {
        final int[] credits = {0, 0, 5, 300};
        model = new StdSlotModel(credits);
    }
    
    private void createView() {
        final int frameWidth = 250;
        final int frameHeight = 120;
        mainFrame = new JFrame("Slot Machine");
        mainFrame.setPreferredSize(new Dimension(frameWidth, frameHeight));
        
        tryButton = new JButton("Tentez votre chance !");
        
        result = new JTextField(model.result());
        result.setEditable(false);
        result.setColumns(3);
        
        won = new JLabel(String.valueOf(model.moneyWon()));
        lost = new JLabel(String.valueOf(model.moneyLost()));
        payout = new JLabel(String.valueOf(model.lastPayout()));
    }
    
    private void placeComponents() {
        JPanel p = new JPanel(); {
            p.setLayout(new FlowLayout());
            p.add(tryButton);
            p.add(result);
        }
        mainFrame.add(p, BorderLayout.NORTH);
        p = new JPanel(); {
            JLabel q = new JLabel("Pertes: ");
            p.add(q);
            p.add(lost);
            q = new JLabel("Gains: ");
            p.add(q);
            p.add(won);
        }
        mainFrame.add(p, BorderLayout.CENTER);
        p = new JPanel(); {
            p.add(new JLabel("Vous venez de gagner: "));
            p.add(payout);
        }
        mainFrame.add(p, BorderLayout.SOUTH);
    }
    
    private void createController() {
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        model.addObserver(new Observer() {
            @Override
            public void update(Observable o, Object arg) {
                refresh();
            }
        });

        tryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.gamble();
            }
        });
    }
    
    private void refresh() {
        result.setText(model.result());
        won.setText(String.valueOf(model.moneyWon()));
        lost.setText(String.valueOf(model.moneyLost()));
        payout.setText(String.valueOf(model.lastPayout()));
    }

    // POINT D'ENTREE
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SlotMachine().display();
            }
        });
    }
}
