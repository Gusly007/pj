package serie07;

import java.awt.BorderLayout;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Swelling {
    
    // ATTRIBUTS
    
    private JFrame mainFrame;
    private SwellingModel model;
    private JButton modify;
    private JButton reset;
    private JTextField factor;
    
    // CONSTRUCTEURS
    
    public Swelling() {
        createModel();
        createView();
        placeComponents();
        createController();
    }
    
    // COMMANDES
    
    /**
     * Rend l'application visible au centre de l'écran.
     */
    public void display() {
        mainFrame.pack();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
        
        model.setMin(mainFrame.getPreferredSize());
        model.setMax(Toolkit.getDefaultToolkit().getScreenSize());
        model.setCurrent(mainFrame.getPreferredSize());
    }
    
    // OUTILS
    
    private void createModel() {
        model = new StdSwellingModel();
    }
    
    private void createView() {
        final int frameWidth = 250;
        final int frameHeight = 120;
        mainFrame = new JFrame("Baudruche");
        mainFrame.setPreferredSize(new Dimension(frameWidth, frameHeight));
        
        modify = new JButton("Modifier");
        reset = new JButton("Réinitialiser");
        
        final int factorWidth = 50;
        final int factorHeight = 20;
        factor =  new JTextField();
        factor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
        factor.setPreferredSize(new Dimension(factorWidth, factorHeight));
    }
    
    private void placeComponents() {
        JPanel p = new JPanel(); {
            JLabel q = new JLabel("Facteur: ");
            p.add(q);
            p.add(factor);
            q = new JLabel("%");
            p.add(q);
            p.add(modify);
        }
        mainFrame.add(p, BorderLayout.NORTH);
        p = new JPanel(); {
            p.add(reset);
        }
        mainFrame.add(p, BorderLayout.SOUTH);
    }
    
    private void createController() {
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        model.addObserver(new Observer() {
            @Override
            public void update(Observable o, Object arg) {
                Dimension d = model.current();
                mainFrame.setSize(d);
            }
        });
        
        modify.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    double value = Double.parseDouble(factor.getText());
                    if (!model.isValidScaleFactor(value)) {
                        throw new NumberFormatException();
                    } else {
                        model.scaleCurrent(value);
                    }
                } catch (NumberFormatException exception) {
                    factor.selectAll();
                    factor.requestFocusInWindow();
                    JOptionPane.showMessageDialog(
                        null, 
                        "Valeur inattendue : " + factor.getText(),
                        "Erreur !",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
                mainFrame.setLocationRelativeTo(null);
            }
        });
        
        reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setCurrent(model.min());
                mainFrame.setLocationRelativeTo(null);
            }
        });
    }

    // POINT D'ENTREE
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Swelling().display();
            }
        });
    }
}
