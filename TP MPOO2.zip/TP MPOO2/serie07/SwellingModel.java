package serie07;

import java.awt.Dimension;

/**
 * Notre modèle représente une taille courante, bornée par une taille min
 *  et une taille max.
 * On peut faire croître et décroître la taille courante à volonté entre les
 *  bornes min et max.
 * On récupère la taille du modèle dans une Dimension par current() et on peut
 *  la modifier de deux manières différentes.
 *  
 * Remarque : dans toute cette spécification, pour deux Dimension d1 et d2,
 *  on note d1 <= d2 ssi d1.width <= d2.width && d1.height <= d2.height.
 *  
 * @inv
 *     min() != null && current() != null && max() != null
 *     max() >= current() >= min() >= 0
 *     isSurroundedBy(d) <==> current() <= d
 *     isSurrounding(d) <==> d <= current()
 *     Soit d(f) ::= new Dimension(
 *                     current().width * (1 + f / 100),
 *                     current().height * (1 + f / 100))
 *     f >= 0
 *         ==> isValidScaleFactor(f) == isSurroundedBy(d(f)) && (d(f) <= max())
 *     f < 0
 *         ==> isValidScaleFactor(f) == (min() <= d(f)) && isSurrounding(d(f)) 
 * @cons
 *     $DESC$ un modèle de min et max égaux à 0
 *     $ARGS$ -
 *     $PRE$ -
 *     $POST$
 *         min().equals(new Dimension(0, 0))
 *         max().equals(new Dimension(0, 0))
 */
public interface SwellingModel extends ObservableModel {
    
    // REQUETES
    
    Dimension current();
    
    /**
     * @pre
     *     d != null
     */
    boolean isSurroundedBy(Dimension d);
    
    /**
     * @pre
     *     d != null
     */
    boolean isSurrounding(Dimension d);
    
    boolean isValidScaleFactor(double f);
    
    Dimension max();
    
    Dimension min();
    
    // COMMANDES
    
    /**
     * @pre
     *     isValidScaleFactor(f)
     * @post
     *     Soit w ::= current().width * (1 + f / CENT)
     *          h ::= current().height * (1 + f / CENT)
     *     current().equals(new Dimension(w, h))
     *     min() == old min()
     *     max() == old max()
     */
    void scaleCurrent(double f);
    
    /**
     * @pre
     *     d != null
     *     min() <= d <= max()
     * @post
     *     min() == old min()
     *     current().equals(d)
     *     max() == old max()
     */
    void setCurrent(Dimension d);
    
    /**
     * @pre
     *     d != null
     *     d >= 0
     * @post
     *     (old min() <= d) ==> min() == old min()
     *     (old min() > d) ==> min().equals(d)
     *     (old current() <= d) ==> current() == old current()
     *     (old current() > d) ==> current().equals(d)
     *     max().equals(d)
     */
    void setMax(Dimension d);
    
    /**
     * @pre
     *     d != null
     *     d >= 0
     * @post
     *     min().equals(d)
     *     (old current() < d) ==> current().equals(d)
     *     (old current() >= d) ==> current() == old current()
     *     (old max() < d) ==> max().equals(d)
     *     (old max() >= d) ==> max() == old max()
     */
    void setMin(Dimension d);
}
