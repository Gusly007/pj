package serie07;

import java.awt.Dimension;
import java.util.Observable;

import util.Contract;

public class StdSwellingModel extends Observable implements SwellingModel {

    // ATTRIBUTS

    private Dimension min;
    private Dimension max;
    private Dimension current;
    private static final int CENT = 100;

    // CONSTRUCTEURS

    public StdSwellingModel() {
        min = new Dimension(0, 0);
        max = new Dimension(0, 0);
        current = new Dimension(0, 0);
    }

    // REQUETES

    @Override
    public Dimension current() {
        Dimension d = new Dimension(current.width, current.height);
        return d;
    }

    @Override
    public boolean isSurroundedBy(Dimension d) {
        Contract.checkCondition(d != null);

        if (current.height <= d.height && current.width <= d.width) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isSurrounding(Dimension d) {
        Contract.checkCondition(d != null);

        if (current.height >= d.height && current.width >= d.width) {
            return true;
        }
        return false;
    }

    @Override
    public boolean isValidScaleFactor(double f) {
        if (f < -CENT) {
            return false;
        }
        int width = (int) (current().width * (1 + (float) (f / CENT)));
        int height = (int) (current().height * (1 + (float) (f / CENT)));
        Dimension d = new Dimension(width, height);
        if (f >= 0) {
            return isSurroundedBy(d) && (d.height <= max.height
                    && d.width <= max.width);
        } else {
            return (min.height <= d.height && min.width <= d.width)
                    && isSurrounding(d);
        }
    }

    @Override
    public Dimension max() {
        Dimension d = new Dimension(max.width, max.height);
        return d;
    }

    @Override
    public Dimension min() {
        Dimension d = new Dimension(min.width, min.height);
        return d;
    }

    // COMMANDES

    @Override
    public void scaleCurrent(double f) {
        Contract.checkCondition(isValidScaleFactor(f));

        int w = (int) (current.width * (1 + f / CENT));
        int h = (int) (current.height * (1 + f / CENT));
        current = new Dimension(w, h);
        setChanged();
        notifyObservers();
    }

    @Override
    public void setCurrent(Dimension d) {
        Contract.checkCondition(d != null);
        Contract.checkCondition(min().height <= d.height
                && d.height <= max().height && min().width <= d.width
                && d.width <= max().width);

        current = d;
        setChanged();
        notifyObservers();
    }

    @Override
    public void setMax(Dimension d) {
        Contract.checkCondition(d != null);
        Contract.checkCondition(0 <= d.height && 0 <= d.width);

        if (min.height > d.height && min.width > d.width) {
            min = d;
        }
        if (current.height > d.height && current.width > d.width) {
            current = d;
        }
        max = d;
        setChanged();
        notifyObservers();
    }

    @Override
    public void setMin(Dimension d) {
        Contract.checkCondition(d != null);
        Contract.checkCondition(0 <= d.height && 0 <= d.width);

        if (current.height < d.height && current.width < d.width) {
            current = d;
        }
        if (max.height < d.height && max.width < d.width) {
            max = d;
        }
        min = d;
        setChanged();
        notifyObservers();
    }

}
