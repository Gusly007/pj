package serie07;

import java.util.Observable;

import util.Contract;

public class StdSlotModel extends Observable implements SlotModel {

    // ATTRIBUTS

    private final int[] credits;
    private final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private int moneyLost;
    private String result;
    private int moneyWon;

    // CONSTRUCTEURS

    public StdSlotModel(int[] credits) {
        Contract.checkCondition(credits != null);
        Contract.checkCondition(credits.length >= MIN_RESULT_SIZE + 1);
        for (int i:credits) {
            Contract.checkCondition(i >= 0);
        }

        this.credits = credits;
        this.moneyLost = 0;
        this.result = "";
        for (int i = 0; i < credits.length - 1; ++i) {
            this.result += " ";
        }
        this.moneyWon = credit(0);
    }

    // REQUETES

    @Override
    public int credit(int n) {
        Contract.checkCondition(0 <= n && n <= result().length());

        return this.credits[n];
    }

    @Override
    public int lastPayout() {
        int[] occs = new int[chars.length()];
        for (int i = 0; i < result.length(); ++i) {
            if (result.charAt(i) != ' ') {
                occs[chars.indexOf(result.charAt(i))]++;
            }
        }
        int max = 0;
        for (int occ:occs) {
            if (occ > max) {
                max = occ;
            }
        }
        return credit(max);
    }

    @Override
    public int moneyLost() {
        return this.moneyLost;
    }

    @Override
    public int moneyWon() {
        return this.moneyWon;
    }

    @Override
    public String result() {
        return this.result;
    }

    // COMMANDES

    @Override
    public void gamble() {
        this.moneyLost++;
        String tmp = "";
        for (int i = 0; i < MIN_RESULT_SIZE; ++i) {
            tmp += chars.charAt((int) (Math.random() * (chars.length())));
        }
        this.result = tmp;
        this.moneyWon += this.lastPayout();
        this.setChanged();
        this.notifyObservers();
    }
}
