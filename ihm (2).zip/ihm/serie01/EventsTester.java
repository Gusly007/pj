package serie01;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class EventsTester {
	//ATTRIBUTS
	private JFrame mainFrame;
	private JFrame testFrame;
	private JButton createFrame;
	private JButton compteur;
	private int cpt;
	private int razCpt;
	
	// Event
	private JTextArea[] listeners;
	private JTextArea windowFocusListener;
	private JTextArea windowListener;
	private JTextArea mouseListener;
	private JTextArea keyListener;
	private JTextArea windowStateListener;
	private JTextArea mouseWheelListener;
	private JTextArea mouseMotionListener;
	
	private static int nombreEvent = 7;
	
	//CONSTRUCTEUR
	public EventsTester() {
		createVue();
		placeComponent();
		createController();
	}
	
	public void display() {
		mainFrame.pack();
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setVisible(true);
		createNewTestFrame();
	}
	
	// OUTILS
	private void createVue() {
		createFrame = new JButton("Nouvelle Fenetre");
		compteur = new JButton("RAZ compteur");
		mainFrame = new JFrame(); {
			mainFrame.setPreferredSize(new Dimension(800,600));
		}
		
		mouseListener = new JTextArea("");
		windowFocusListener = new JTextArea("");
		windowListener = new JTextArea("");
		keyListener = new JTextArea("");
		windowStateListener = new JTextArea("");
		mouseWheelListener = new JTextArea("");
		mouseMotionListener = new JTextArea("");
		listeners = new JTextArea[nombreEvent]; {
			listeners[0] = mouseListener;
			listeners[1] = windowFocusListener;
			listeners[2] = windowListener;
			listeners[3] = keyListener;
			listeners[4] = windowStateListener;
			listeners[5] = mouseWheelListener;
			listeners[6] = mouseMotionListener;
		}
		
		for (JTextArea ta : listeners) {
			ta.setEditable(false);
		}
	}
	
	private void placeComponent() {
		JPanel p = new JPanel(); {
			p.add(createFrame);
			p.add(compteur);
		}
		mainFrame.add(p, BorderLayout.NORTH);
		p = new JPanel(new BorderLayout()); {
			p.setBorder(BorderFactory.createEtchedBorder());
			JPanel q = new JPanel(new GridLayout(0, 3)); {
				JPanel r = new JPanel(new BorderLayout()); {
					r.setBorder(BorderFactory.createTitledBorder("MouseListener"));
					r.add(new JScrollPane(mouseListener), BorderLayout.CENTER);
				}
				q.add(r);
				r = new JPanel(new BorderLayout()); {
					r.setBorder(BorderFactory.createTitledBorder("WindowFocusListener"));
					r.add(new JScrollPane(windowFocusListener), BorderLayout.CENTER);
				}
				q.add(r);
				r = new JPanel(new BorderLayout()); {
					r.setBorder(BorderFactory.createTitledBorder("WindowListener"));
					r.add(new JScrollPane(windowListener), BorderLayout.CENTER);
				}
				q.add(r);
				r = new JPanel(new BorderLayout()); {
					r.setBorder(BorderFactory.createTitledBorder("KeyListener"));
					r.add(new JScrollPane(keyListener), BorderLayout.CENTER);
				}
				q.add(r);
				r = new JPanel(new BorderLayout()); {
					r.setBorder(BorderFactory.createTitledBorder("WindowStateListener"));
					r.add(new JScrollPane(windowStateListener), BorderLayout.CENTER);
				}
				q.add(r);
				r = new JPanel(new BorderLayout()); {
					r.setBorder(BorderFactory.createTitledBorder("MouseWheelListener"));
					r.add(new JScrollPane(mouseWheelListener), BorderLayout.CENTER);
				}
				q.add(r);
				r = new JPanel(new BorderLayout()); {
					r.setBorder(BorderFactory.createTitledBorder("MouseMotionListener"));
					r.add(new JScrollPane(mouseMotionListener), BorderLayout.CENTER);
				}
				q.add(r);
			}
			p.add(q, BorderLayout.CENTER);
		}
		mainFrame.add(p, BorderLayout.CENTER);
	}
	
	private void createController() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		createFrame.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				clearText();
				createNewTestFrame();
			}
		});
		
		compteur.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				razCompteur();
			}
		});
	}
	
	private void clearText() {		
		int option = JOptionPane.showConfirmDialog(null, 
				"Voulez-vous rénitialiser l'affichage ?", 
				"Nettoyage de l'affichage", 
				JOptionPane.YES_NO_OPTION, 
				JOptionPane.QUESTION_MESSAGE);

		if(option != JOptionPane.NO_OPTION && 
				option == JOptionPane.OK_OPTION) {
			for (JTextArea ta : listeners) {
				ta.setText("");
				
			}
			cpt = 0;
			razCpt = 0;
		}
	}

	private void createNewTestFrame() {
		if (testFrame != null) {
			testFrame.dispose();
		}
		testFrame = new JFrame("Zone de test");
		testFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		testFrame.setLocationRelativeTo(null);
		testFrame.setPreferredSize(new Dimension(200,100));
		testFrame.pack();
		testFrame.setVisible(true);
		refresh_controllers();
	}
	
	private void refresh_controllers() {
		testFrame.addMouseListener(new MouseListener() {
			public void mouseClicked(MouseEvent e) {
				cpt++;
				mouseListener.append(cpt + " MOUSE_CLICKED\n");
			}

			public void mousePressed(MouseEvent e) {
				cpt++;
				mouseListener.append(cpt + " MOUSE_PRESSED\n");
			}

			public void mouseReleased(MouseEvent e) {
				cpt++;
				mouseListener.append(cpt + " MOUSE_RELEASED\n");
			}

			public void mouseEntered(MouseEvent e) {
				cpt++;
				mouseListener.append(cpt + " MOUSE_ENTERED\n");
			}

			public void mouseExited(MouseEvent e) {
				cpt++;
				mouseListener.append(cpt + " MOUSE_EXITED\n");
			}
			
		});
		
		testFrame.addFocusListener(new FocusListener() {
			public void focusGained(FocusEvent e) {
				cpt++;
				windowFocusListener.append(cpt + " FOCUS_GAINED\n");
			}

			public void focusLost(FocusEvent e) {
				cpt++;
				windowFocusListener.append(cpt + " FOCUS_LOST\n");
			}
		});
		
		testFrame.addWindowListener(new WindowListener() {
			public void windowOpened(WindowEvent e) {
				cpt++;
				windowListener.append(cpt + " WINDOW_OPENED\n");
			}

			public void windowClosing(WindowEvent e) {
				cpt++;
				windowListener.append(cpt + " WINDOW_CLOSING\n");
			}

			public void windowClosed(WindowEvent e) {
				cpt++;
				windowListener.append(cpt + " WINDOW_CLOSED\n");
			}

			public void windowIconified(WindowEvent e) {
				cpt++;
				windowListener.append(cpt + " WINDOW_INCONIFIED\n");
			}

			public void windowDeiconified(WindowEvent e) {
				cpt++;
				windowListener.append(cpt + " WINDOW_DEICONIFIED\n");
			}

			public void windowActivated(WindowEvent e) {
				cpt++;
				windowListener.append(cpt + " WINDOW_ACTIVATED\n");
			}

			public void windowDeactivated(WindowEvent e) {
				cpt++;
				windowListener.append(cpt + " WINDOW_DEACTIVATED\n");
			}
		});
		
		testFrame.addKeyListener(new KeyListener() {
			public void keyTyped(KeyEvent e) {
				cpt++;
				keyListener.append(cpt + " KEY_TYPED\n");
			}

			public void keyPressed(KeyEvent e) {
				cpt++;
				keyListener.append(cpt + " KEY_PRESSED\n");
			}

			public void keyReleased(KeyEvent e) {
				cpt++;
				keyListener.append(cpt + " KEY_RELEASED\n");
			}
		});
	
		testFrame.addWindowStateListener(new WindowStateListener() {
			public void windowStateChanged(WindowEvent e) {
				cpt++;
				windowStateListener.append(cpt + " STATE_CHANGED\n");
			}
		});
	
		testFrame.addMouseWheelListener(new MouseWheelListener() {
			public void mouseWheelMoved(MouseWheelEvent e) {
				cpt++;
				mouseWheelListener.append(cpt + " MOUSE_WHEEL_MOVED\n");
			}
		});
	
		testFrame.addMouseMotionListener(new MouseMotionListener() {
			public void mouseDragged(MouseEvent e) {
				cpt++;
				mouseMotionListener.append(cpt + " MOUSE_DRAGGED\n");
			}

			public void mouseMoved(MouseEvent e) {
				cpt++;
				mouseMotionListener.append(cpt + " MOUSE_MOVED\n");
			}
		});
	}
	
	private void razCompteur() {
		cpt = 0;
		razCpt++;
		for (JTextArea ta : listeners) {
			ta.append("--- RAZ " + razCpt + " ---\n");;
		}
	}
	
	// POINT D'ENTREE
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new EventsTester().display();
            }
        });
    }
}
