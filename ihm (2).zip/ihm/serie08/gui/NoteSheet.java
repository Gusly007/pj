package serie08.gui;

import java.io.File;

import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.event.ChangeListener;

import serie08.model.application.NoteSheetModel;
import serie08.model.gui.NoteTableModel;

public class NoteSheet extends JPanel {
	
	// ATTRIBUTS
	private NoteSheetModel appliModel;
	private NoteTableModel guiModel;
	private JTable table;
	
	public NoteSheet() {
		//appliModel = new DefaultNoteSheetModel();
		guiModel = new DefaultNoteTableModel();
		table = new JTable();
	}
	
	public NoteTableModel getTableModel() {
		return guiModel;
	}
	public double getMean() {
		return appliModel.getMean(guiModel);
	}
	public double getPoints() {
		return appliModel.getPoints(guiModel);
	}
	public int getProgress() {
		
	}
	public void loadFile(File f) {
		
	}
	public void saveFile(File f) {
		
	}
	public void addProgressListener(ChangeListener cl) {
		
	}
	public void removeProgressListener(ChangeListener cl) {
		
	}
}
