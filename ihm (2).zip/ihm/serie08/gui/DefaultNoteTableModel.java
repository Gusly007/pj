package serie08.gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import serie08.model.gui.NoteTableModel;

public class DefaultNoteTableModel extends AbstractTableModel implements NoteTableModel {
	
	private Object[][] data;
	private Object[] colNames;
	
	public DefaultNoteTableModel() {
		
	}

	@Override
	public int getRowCount() {
		return super.get;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		return this.getValueAt(rowIndex, columnIndex);
	}

	@Override
	public List<Object> getEmptyDataRow() {
		return this.getEmptyDataRow();
	}

	@Override
	public void addRow(List<Object> line) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clearRows() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertRow(List<Object> line, int index) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeRow(int index) {
		// TODO Auto-generated method stub
		
	}

}
