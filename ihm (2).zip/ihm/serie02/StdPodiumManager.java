package serie02;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.beans.VetoableChangeSupport;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class StdPodiumManager<E extends Drawable> implements PodiumManager<E> {
	// ATTRIBUTS
	private Order lastOrder;
	private Map<Rank, Podium<E>> podiums;
	private int shotsNb;
	private long timeDelta;
	private boolean finished;
	private Set<E> drawables;
	private PropertyChangeSupport changeSupport;
	private VetoableChangeSupport vetoableChangeSupport;
	
	// CONSTRUCTEUR
	public StdPodiumManager(Set<E> drawables) {
		if (drawables == null || drawables.size() < 2) {
			throw new AssertionError();
		}
		podiums = new HashMap<Rank, Podium<E>>();
		this.drawables = drawables;
		List<List<E>> lst = createRandomElements();
	    lst.addAll(createRandomElements());
	    for (Rank r : Rank.values()) {
	        podiums.put(r, 
	        		new Podium<E>(new StdPodiumModel<E>(
	                        lst.get(r.ordinal()),
	                        drawables.size()
	                ))
	        );
	    }
		shotsNb = 0;
		timeDelta = System.currentTimeMillis();
		lastOrder = null;
		finished = false;
	}
	

	// REQUETES
	@Override
	public Order getLastOrder() {
		return lastOrder;
	}

	@Override
	public Map<Rank, Podium<E>> getPodiums() {
		return podiums;
	}

	@Override
	public int getShotsNb() {
		return shotsNb;
	}

	@Override
	public long getTimeDelta() {
		return (System.currentTimeMillis() - timeDelta)/1000;
	}

	@Override
	public boolean isFinished() {
		return finished;
	}
	
	// COMMANDES

	@Override
	public void addPropertyChangeListener(String propName, PropertyChangeListener lst) {
		if (propName == null) {
			throw new AssertionError();
		}
		if (changeSupport == null) {
			changeSupport = new PropertyChangeSupport(this);
		}
		changeSupport.addPropertyChangeListener(propName, lst);
	}

	@Override
	public void addVetoableChangeListener(VetoableChangeListener lst) {
		if (lst == null) {
			throw new AssertionError();
		}
		if (vetoableChangeSupport == null) {
			vetoableChangeSupport = new VetoableChangeSupport(this);
		}
		vetoableChangeSupport.addVetoableChangeListener(lst);
	}

	@Override
	public void executeOrder(Order o) throws PropertyVetoException {
		if (o == null) {
			throw new AssertionError();
		}
		Map<Rank, Podium<E>> mp = getPodiums();
		if (o == Order.LO) {
			sendTo(mp.get(Rank.WRK_LEFT).getModel(), 
					mp.get(Rank.WRK_RIGHT).getModel());
		}
		else if (o == Order.KI) {
			sendTo(mp.get(Rank.WRK_RIGHT).getModel(), 
					mp.get(Rank.WRK_LEFT).getModel());
		}
		else if (o.equals(Order.MA)) {
			moveUp(mp.get(Rank.WRK_LEFT).getModel());
		}
		else if (o == Order.NI) {
			moveUp(mp.get(Rank.WRK_RIGHT).getModel());
		}
		else if (o == Order.SO) {
			fireVetoableChange("lastOrder", null, o);
			swap(mp.get(Rank.WRK_LEFT).getModel(), 
					mp.get(Rank.WRK_RIGHT).getModel());
		}
		firePropertyChange("lastOrder", null, o.name());
		lastOrder = o;
		shotsNb++;
		boolean bool = podiums.get(Rank.OBJ_LEFT).getModel().equals(podiums.get(Rank.WRK_LEFT).getModel()) &&
				podiums.get(Rank.OBJ_RIGHT).getModel().equals(podiums.get(Rank.WRK_RIGHT).getModel());
		changeSupport.firePropertyChange("isFinished", finished, bool);
		finished = bool;
	}

	@Override
	public void reinit() {
		changePodiumModels();
		shotsNb = 0;
		timeDelta = System.currentTimeMillis();
		changeSupport.firePropertyChange("newGame", null, true);
		lastOrder = null;
		boolean bool = podiums.get(Rank.OBJ_LEFT).getModel().equals(podiums.get(Rank.WRK_LEFT).getModel()) &&
				podiums.get(Rank.OBJ_RIGHT).getModel().equals(podiums.get(Rank.WRK_RIGHT).getModel());
		changeSupport.firePropertyChange("isFinished", null, bool);
		finished = bool;
	}

	@Override
	public void removePropertyChangeListener(PropertyChangeListener lst) {
		if (lst == null) {
			throw new AssertionError();
		}
		changeSupport.removePropertyChangeListener(lst);
	}

	@Override
	public void removeVetoableChangeListener(VetoableChangeListener lst) {
		if (lst == null) {
			throw new AssertionError();
		}
		vetoableChangeSupport.removeVetoableChangeListener(lst);
	}
	
	// OUTILS 
	// cette méthode est appelée par reinit()
	/**
	 * Construit les 4 séquences d'éléments de E, puis les 4 modèles de podiums
	 *  basés sur ces séquences.
	 * La concaténation des deux premières séquences est une permutation des
	 *  éléments de drawables.
	 * La concaténation des deux dernières séquences est aussi une permutation
	 *  des éléments de drawables.
	 * Il se peut que les permutations soient identiques.
	 */
	private void changePodiumModels() {
	    List<List<E>> lst = createRandomElements();
	    lst.addAll(createRandomElements());
	    for (Rank r : Rank.values()) {
	        podiums.get(r).setModel(
	                new StdPodiumModel<E>(
	                        lst.get(r.ordinal()),
	                        drawables.size()
	                )
	        );
	    }
	}
	/**
	 * Construit une séquence de deux séquences aléatoires d'éléments de E, à
	 *  partir de l'ensemble drawables, un peu comme in distribue des cartes :
	 *  - on commence par mélanger les cartes,
	 *  - puis on les distribue au hasard, une par une, en deux tas.
	 */
	private List<List<E>> createRandomElements() {
	    final double ratio = 0.5;
	    List<E> elements = new LinkedList<E>(drawables);
	    List<E> list = new ArrayList<E>(drawables.size());
	    for (int i = drawables.size(); i > 0; i--) {
	        int k = ((int) (Math.random() * i));
	        list.add(elements.get(k));
	        elements.remove(k);
	    }
	    List<E> elemsL = new ArrayList<E>(drawables.size());
	    List<E> elemsR = new ArrayList<E>(drawables.size());
	    for (E e : list) {
	        if (Math.random() < ratio) {
	            elemsL.add(e);
	        } else {
	            elemsR.add(e);
	        }
	    }
	    ArrayList<List<E>> result = new ArrayList<List<E>>(2);
	    result.add(elemsL);
	    result.add(elemsR);
	    return result;
	}
	
	private void sendTo(PodiumModel<E> src, PodiumModel<E> dst) {
		if (src.size() > 0) {
			dst.addTop(src.top());
			src.removeTop();
		}
	}
	
	private void swap(PodiumModel<E> pm1, PodiumModel<E> pm2) {
		if (pm1.size() > 0 && pm2.size() > 0) {
			E elem = pm1.top();
			pm1.removeTop();
			pm1.addTop(pm2.top());
			pm2.removeTop();
			pm2.addTop(elem);
		}
	}
	
	private void moveUp(PodiumModel<E> pm) {
		if (pm.size() > 1) {
			E elem = pm.bottom();
			pm.removeBottom();
			pm.addTop(elem);
		}
	}

	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) { 
		PropertyChangeSupport changeSupport = this.changeSupport; 
		if (changeSupport == null || (oldValue != null && newValue != null && oldValue.equals(newValue))) {
			return; 
			}
		changeSupport.firePropertyChange(propertyName, oldValue, newValue);
	}
	
	protected void fireVetoableChange(String propertyName, Object oldValue, Object newValue)
	        throws PropertyVetoException
	    {
	        if (vetoableChangeSupport == null) {
	            return;
	        }
	        vetoableChangeSupport.fireVetoableChange(propertyName, oldValue, newValue);
	    }
}
