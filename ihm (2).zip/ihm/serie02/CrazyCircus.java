package serie02;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.util.Map;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import serie02.PodiumManager.Order;
import serie02.PodiumManager.Rank;

public class CrazyCircus<E extends Drawable> {
	// ATTRIBUTS
	private JFrame mainFrame;
	private PodiumManager<E> manager;
	private Map<Rank, Podium<E>> podiums;
	
	private JButton[] orderButtons;
	private JButton newgameButton;
	private JTextArea textOrder;
	private JCheckBox allowedSO;
	
	// CONSTRUCTEUR
	public CrazyCircus(Set<E> drawables) {
		createModel(drawables);
		createView();
		placeComponents();
		createController();
	}  
	
	// COMMANDES
	public void display() {
		mainFrame.setLocationRelativeTo(null);
		mainFrame.pack();
		mainFrame.setVisible(true);
	}

	// OUTILS
	private void createModel(Set<E> drawables) {
		manager = new StdPodiumManager<E>(drawables);
		podiums = manager.getPodiums();
	}
	
	private void createView() {
		mainFrame = new JFrame("Crazy Circus"); {
			mainFrame.setPreferredSize(new Dimension(360, 320));
		}
		orderButtons = new JButton[Order.values().length];
		for (Order o : PodiumManager.Order.values()) {
			orderButtons[o.ordinal()] = new JButton(o.toString());
		}
		allowedSO = new JCheckBox();
		newgameButton = new JButton("Nouvelle Partie");
		textOrder = new JTextArea(); {
			textOrder.setRows(3);
			textOrder.setLineWrap(true);
			textOrder.setWrapStyleWord(true);
			textOrder.setEditable(false);
		}
	}
	
	private void placeComponents() {
		JPanel p = new JPanel(new BorderLayout()); {
			JPanel q = new JPanel(new BorderLayout()); {
				q.add(podiums.get(Rank.WRK_LEFT), BorderLayout.WEST);
				q.add(podiums.get(Rank.WRK_RIGHT), BorderLayout.EAST);
				JPanel r = new JPanel(); {
					r.add(new JLabel("Départ"));
				}
				q.add(r, BorderLayout.SOUTH);
			}
			p.add(q, BorderLayout.WEST);
			q = new JPanel(new BorderLayout()); {
				q.add(podiums.get(Rank.OBJ_LEFT), BorderLayout.WEST);
				q.add(podiums.get(Rank.OBJ_RIGHT), BorderLayout.EAST);
				JPanel r = new JPanel(); {
					r.add(new JLabel("Objectif"));
				}
				q.add(r, BorderLayout.SOUTH);
			}
			p.add(q, BorderLayout.EAST);
		}
		mainFrame.add(p, BorderLayout.CENTER);
		p = new JPanel(); {
			JPanel q = new JPanel(new GridLayout(0,1)); {
				for (JButton b : orderButtons) {
					q.add(b);
				}
				JPanel r = new JPanel(); {
					r.setBorder(BorderFactory.createLineBorder(Color.black));
					r.add(allowedSO);
					r.add(new JLabel("Autoriser " + Order.SO.name()));
				}
				q.add(r);
				q.add(newgameButton);
			}
			p.add(q);
		}
		mainFrame.add(p, BorderLayout.EAST);
		mainFrame.add(new JScrollPane(textOrder), BorderLayout.SOUTH);
	}
	
	private void createController() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		newgameButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				manager.reinit();
			}
		});
		
		manager.addPropertyChangeListener("lastOrder", new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				textOrder.append(evt.getNewValue().toString() + " ");	
			}
		});
		
		manager.addPropertyChangeListener("isFinished", new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				if (evt.getNewValue().equals(true)) {
					textOrder.append("\nGagné en " + manager.getShotsNb() + " coups et " + manager.getTimeDelta() + " s.");
					for (Order o : Order.values()) {
						orderButtons[o.ordinal()].setEnabled(false);
					}
				}
				if (evt.getNewValue().equals(false)) {
					textOrder.setText("");
					for (Order o : Order.values()) {
						orderButtons[o.ordinal()].setEnabled(true);
					}
				}
			}
		});
		
		manager.addVetoableChangeListener(new VetoableChangeListener() {
			public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException {
				if(!allowedSO.isSelected()) {
					throw new PropertyVetoException("SO is not allowed", evt);
				}
			}
		});
		
		for (Order o : Order.values()) {
			orderButtons[o.ordinal()].addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					try {
						manager.executeOrder(o);
					} catch (PropertyVetoException e1) {
						Toolkit.getDefaultToolkit().beep();     
					}
				}
			});
		}
	}
}
