package layouts;

import java.awt.Dimension;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class BoxDistrib extends Distrib {

	public BoxDistrib(String title) {
		super(title);
	}

	@Override
	protected void placeComponents() {
		JPanel p = new JPanel(null); {
			JLabel l = LKey.BACK.jlabel();
			l.setAlignmentX(0.5f);
			p.add(l);
			l = LKey.CREDIT.jlabel();
			l.setAlignmentX(0.5f);
			p.add(l);
			JButton b = BKey.ORANGE.jbutton();
			b.setAlignmentX(0.5f);
			b.setMaximumSize(new Dimension(Integer.MAX_VALUE, b.getPreferredSize().height));
			p.add(b);
		}
		p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
		getFrame().add(p);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new BoxDistrib("BoxDistrib de boisson").display();
			}
		});
	}

}
