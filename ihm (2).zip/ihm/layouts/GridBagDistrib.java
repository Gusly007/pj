package layouts;

import java.awt.BorderLayout;
import java.awt.GridBagLayout;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class GridBagDistrib extends Distrib {
	
	public GridBagDistrib(String title) {
		super(title);
	}

	@Override
	protected void placeComponents() {
		GBC[] constraints = new GBC[] {
			new GBC(0, 0, 6, 1).anchor(GBC.CENTER), // quatre
			new GBC(0, 1, 6, 1).anchor(GBC.CENTER),
			new GBC(0, 8),
			new GBC(3, 8),
			
			new GBC(0, 2, 2, 2).fill(GBC.BOTH).anchor(GBC.WEST),
			new GBC(0, 4, 2, 2).fill(GBC.BOTH).anchor(GBC.WEST),
			new GBC(0, 6, 2, 2).fill(GBC.BOTH).anchor(GBC.WEST),
			
			new GBC(2, 2, 1, 2).fill(GBC.BOTH).weight(1, 0),
			new GBC(2, 4, 1, 2).fill(GBC.BOTH),
			new GBC(2, 6, 1, 2).fill(GBC.BOTH),
			
			new GBC(3, 3, 2, 2).fill(GBC.BOTH),
			new GBC(3, 5, 2, 2).fill(GBC.BOTH),
			
			new GBC(5, 3).fill(GBC.HORIZONTAL).weight(1, 0),
			new GBC(1, 8, 2, 1).fill(GBC.HORIZONTAL),
			new GBC(4, 8, 2, 1).fill(GBC.HORIZONTAL),
			
			new GBC(0, 9, 7, 1).anchor(GBC.CENTER).anchor(GBC.NORTH).weight(0, 1),
			
			new GBC(6, 3, 1, 2).anchor(GBC.CENTER),
			new GBC(6, 8).anchor(GBC.CENTER),
			
			new GBC(3, 2)
		};
		JPanel p = new JPanel(new GridBagLayout()); {
			p.add(LKey.BACK.jlabel(), constraints[0]);
			p.add(LKey.CREDIT.jlabel(), constraints[1]);
			p.add(LKey.DRINK.jlabel(), constraints[2]);
			p.add(LKey.MONEY.jlabel(), constraints[3]);
			
			p.add(BKey.ORANGE.jbutton(), constraints[4]);
			p.add(BKey.CHOCO.jbutton(), constraints[5]);
			p.add(BKey.COFFEE.jbutton(), constraints[6]);
			
			p.add(PKey.ORANGE.jlabel(), constraints[7]);
			p.add(PKey.CHOCO.jlabel(), constraints[8]);
			p.add(PKey.COFFEE.jlabel(), constraints[9]);
			
			p.add(BKey.INS.jbutton(), constraints[10]);
			p.add(BKey.CANCEL.jbutton(), constraints[11]);
			
			p.add(FKey.INS.jtextfield(), constraints[12]);
			p.add(FKey.DRINK.jtextfield(), constraints[13]);
			p.add(FKey.MONEY.jtextfield(), constraints[14]);
			
			p.add(BKey.TAKE.jbutton(), constraints[15]);
			
			p.add(PKey.INS.jlabel(), constraints[16]);
			p.add(PKey.MONEY.jlabel(), constraints[17]);
			
		}
		getFrame().add(p);
	}

	// POINT D'ENTREE
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new GridBagDistrib("GridBagDistrib de boisson").display();
			}
		});
	}
}
