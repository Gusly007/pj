package serie07.util;


public final class StringTranslator implements ValueTranslator<String> {
    
    public String translateText(String text) {
        return text;
    }
    
    public String translateValue(String value) {
        return value;
    }
}
