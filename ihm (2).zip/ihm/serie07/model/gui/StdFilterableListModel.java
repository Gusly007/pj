package serie07.model.gui;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.swing.AbstractListModel;

import serie07.model.filters.Filter;
import serie07.model.filters.Filterable;

public class StdFilterableListModel<E extends Filterable<V>, V> extends AbstractListModel<E> implements FilterableListModel<E, V> {

	// ATTRIBUTS
	
	private Filter<E, V> filtre;
	
	private List<E> unfilteredList;
	private List<E> filteredList;
	private PropertyChangeListener propertyChange;
	
	// CONSTRUCTEUR
	
	public StdFilterableListModel() {
		unfilteredList = new ArrayList<E>();
		propertyChange = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				filteredList = filtre.filter(unfilteredList);
				fireContentsChanged(evt, 0, unfilteredList.size());
			}
		};
	}
	
	// REQUETES
	
	@Override
	public Filter<E, V> getFilter() {
		return filtre;
	}

	@Override
	public E getElementAt(int i) {
		return filteredList.get(i);
	}

	@Override
	public int getSize() {
		return filteredList.size();
	}

	@Override
	public E getUnfilteredElementAt(int i) {
		return list.get(i);
	}

	@Override
	public int getUnfilteredSize() {
		return list.size();	
	}

	// COMMANDES
	
	@Override
	public void addElement(E element) {
		list.add(element);
		if(filtre != null && filtre.isValid(element)) {
			filteredList.add(element);
		}
		//this.fireContentsChanged(this, filteredList.size()-2, filteredList.size()-1);
	}

	@Override
	public void setFilter(Filter<E, V> filter) {
		if (filtre != null) {
			filtre.removeValueChangeListener(propertyChange);
		}
		this.filtre = filter;
		filtre.addValueChangeListener(propertyChange);
		this.fireContentsChanged(this, 0, filteredList.size()-1);
	}

	@Override
	public void setElements(Collection<E> c) {
		list.clear();
		list.addAll(c);
		filteredList = filtre.filter(list);
		this.fireContentsChanged(this, 0, filteredList.size()-1);
	}
}
