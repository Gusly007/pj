package serie07.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

import serie07.model.filters.Filter;
import serie07.model.filters.Filterable;
import serie07.model.filters.Prefix;
import serie07.model.gui.FilterableListModel;
import serie07.model.gui.StdFilterableListModel;
import serie07.util.ValueTranslator;

public class FilterablePane<E extends Filterable<V>, V> extends JPanel {
	
	// ATTRIBUTS
	private JTextField filterText;
	private JList<String> filterableList;
	private JComboBox<String> filterTypes;
	private Filter<E, V> filtre;
	private List<Filter<E, V>> filtres;
	
	private FilterableListModel<E, V> model;
	
	private ValueTranslator<V> translator;
	
	// CONSTRUCTEUR
	public FilterablePane(ValueTranslator<V> translator) {
		model = new StdFilterableListModel<E, V>();
		this.translator = translator;
		createView();
		placeComponent();
		createController();
	}
	
	// COMMANDE
	
	public void setFilters(List<Filter<E, V>> filters) {
		filterTypes.removeAllItems();
		for (Filter<E, V> f : filters) {
			filterTypes.addItem(f.toString());
		}
		this.filtres = filters;
	}
	
	public void addElement(E e) {
		System.out.println(e.toString());
		//model.addElement(e);
	}
	
	// OUTILS
	private void createView() {
		this.setPreferredSize(new Dimension(400,700));
		filterTypes = new JComboBox<String>();
		filterText = new JTextField(); {
			filterText.setColumns(22);
		}
		filterableList = new JList<String>();
	}
	
	private void placeComponent() {
		JPanel p = new JPanel(new BorderLayout()); {
			JPanel q = new JPanel(); {
				q.add(filterTypes, BorderLayout.WEST);
				q.add(filterText, BorderLayout.CENTER);
			}
			p.add(q, BorderLayout.NORTH);
			q = new JPanel(); {
				q.add(filterableList, BorderLayout.CENTER);
			}
			p.add(new JScrollPane(q), BorderLayout.CENTER);
		}
		this.add(p);
	}
	
	private void createController() {/*
		// keypress
		Document doc = filterText.getDocument();
		doc.addDocumentListener(new DocumentListener() {
			@Override
			public void insertUpdate(DocumentEvent e) {
				Filter<E, V> f = model.getFilter();
				try {
					String s = doc.getText(0, doc.getLength());
					V v = translator.translateText(s);
					f.setValue(v);
				} catch (BadLocationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

			@Override
			public void removeUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		// Changement du filtre
		filterTypes.addItemListener(new ItemListener(){
			public void itemStateChanged(ItemEvent e) {
				filtre = filtres.get(filterTypes.getSelectedIndex());
				V v = translator.translateText(filterText.getText());
				filtre.setValue(v);
				model.setFilter(filtre);
			}
		});

		// Update de l'affichage de la JList
		model.addListDataListener(new ListDataListener(){
			public void intervalAdded(ListDataEvent e) {
				//
			}

			public void intervalRemoved(ListDataEvent e) {
				//
			}

			public void contentsChanged(ListDataEvent e) {
				filterableList.repaint();
			}
			
		});*/
	}
	
	// POINT D'ENTREE
}
