package serie05;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class MobileComponent extends JComponent implements AnimableComponent {

    private Mobile model;
    private boolean caught;
    private Point savedPoint;
    
	public MobileComponent(int width, int height, int ray) {
		super();
		model = new StdMobile(new Rectangle(0, 0, width, height), new Rectangle(1, 1, 2*ray, 2*ray));
		model.setHorizontalShift(0);
		model.setVerticalShift(0);
		caught = false;
		setPreferredSize(new Dimension(width, height));
		setOpaque(true);
		createController();
	}
	
	public void paintComponent(Graphics g) {
		g.setColor(STAT_COLOR);
		g.fillRect(0, 0, model.getStaticRect().width, model.getStaticRect().height);
		g.setColor(MOV_COLOR);
		int width = model.getMovingRect().width;
		int height = model.getMovingRect().height;
		g.fillRoundRect(model.getMovingRect().x, 
				model.getMovingRect().y, 
				width, 
				height, 
				width, 
				height);
		Toolkit.getDefaultToolkit().sync();
	}

	
	private void createController() {
		this.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (model.getMovingRect().contains(new Point(e.getX(), e.getY()))) {
					caught = true;
					savedPoint = model.getCenter();
				}
			}
			
			public void mouseReleased(MouseEvent e) {
				if (caught) {
					model.setHorizontalShift(model.getCenter().x - savedPoint.x);
					model.setVerticalShift(model.getCenter().y - savedPoint.y);
					model.setCenter(savedPoint);
					caught = false;
				}
			}
        });
		
		this.addMouseMotionListener(new MouseAdapter() {
			public void mouseDragged(MouseEvent e) {
				if (caught == true) {
					if (model.isValidCenterPosition(e.getPoint())) {
						model.setCenter(e.getPoint());
					}
				}
			}
		});
		
		model.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				repaint();
			}
		});
	}


	@Override
	public Point getDiscCenter() {
		return model.getCenter();
	}

	@Override
	public int getHorizontalShift() {
		return model.getHorizontalShift();
	}

	@Override
	public Mobile getModel() {
		return model;
	}

	@Override
	public int getVerticalShift() {
		return model.getVerticalShift();
	}

	@Override
	public boolean isDiscCaught() {
		return caught;
	}

	@Override
	public void animate() {
		if (!caught) {
			model.move();
		}
	}

	@Override
	public void setDiscCenter(Point p) {
		model.setCenter(p);
	}

	@Override
	public void setDiscShift(int dx, int dy) {
		model.setHorizontalShift(dx);
		model.setVerticalShift(dy);
	}
	
	
	
}
