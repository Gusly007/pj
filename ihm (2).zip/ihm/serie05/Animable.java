package serie05;

public interface Animable {
    
    // COMMANDE
    
    void animate();
}
