package serie05;

import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.EventListenerList;

import util.Contract;

public class GraphicAnimator {
	// ATTRIBUTS
	private SharedState state;
	private Thread animThread;
	private Animable animable;
	private EventListenerList listenerList;
	private ChangeEvent changeEvent;
	private int maxMovesPerSecond;

	// CONSTRUCTEUR
	public GraphicAnimator(Animable tested, int maxMovesSecond) {
		state = new SharedState();
		changeEvent = new ChangeEvent(this);
		maxMovesPerSecond = maxMovesSecond;
		animable = tested;
	}
	
	// REQUETES
	public boolean isAnimationPaused() {
		return state.isPaused();
	}
	
	public boolean isAnimationRunning() {
		return state.isRunning();
	}
	
	public boolean isAnimationStopped() {
		return state.isStopped();
	}
	
	public boolean isAnimationStarted() {
		return state.isStarted();
	}
	
	public int getSpeed() {
		return state.getSpeed();
	}

	public int getMaxSpeed() {
		return maxMovesPerSecond;
	}
	
	// COMMANDES
	public void startAnimation() {
		if (animThread == null) {
			animThread = new AnimationLoop(animable);
		}
		
		if (animThread.getState() != Thread.State.NEW) {
			animThread = new AnimationLoop(animable);
			
		}
		state.start();
		fireStateChanged();
		
		animThread.start();
	}
	
	public void pauseAnimation() {
		state.pause();
		fireStateChanged();
	}
	
	public void resumeAnimation() {
		state.pause();
		fireStateChanged();
	}
	
	public void stopAnimation() {
		state.stop();
		animThread.interrupt();
		fireStateChanged();
	}
	
	public void setSpeed(int d) {
		Contract.checkCondition(d >= 0 || d <= maxMovesPerSecond, "Invalide Speed");
		state.setSpeed(d);
		fireStateChanged();
	}
	
	public void addChangeListener(ChangeListener changeListener) {
		if (listenerList == null) {
			listenerList = new EventListenerList();
		}
		listenerList.add(ChangeListener.class, changeListener);
	}
	
	public void removeChangeListener(ChangeListener changeListener) {
		if (listenerList == null) {
			listenerList = new EventListenerList();
		}
		listenerList.remove(ChangeListener.class, changeListener);
	}
	
	protected void fireStateChanged() {
		if (SwingUtilities.isEventDispatchThread()) {
			ChangeListener[] listeners = listenerList.getListeners(ChangeListener.class);
	        for (ChangeListener lst : listeners) {
	            lst.stateChanged(changeEvent);
	        }
		}
    }
	
	// OUTILS
	private class SharedState {
		private boolean started;
        private boolean stopped;
        private boolean paused;
        private volatile int movesPerSecond;
        
        // REQUETE
        synchronized int getSpeed() {
        	return movesPerSecond;
        }
        
        synchronized boolean isPaused() {
            return started && !stopped && paused;
        }
        
        synchronized boolean isRunning() {
            return started && !stopped;
        }
        
        synchronized boolean isStopped() {
            return !started && stopped && !paused;
        }
        
        synchronized boolean isStarted() {
            return started && !stopped;
        }
        
        // COMMANDE
        synchronized void setSpeed(int movesSecond) {
        	movesPerSecond = movesSecond;
        }
        synchronized void pause() {
        	started = true;
        	stopped = false;
            paused = !paused;   
        }
        
        synchronized void stop() {
        	started = false;
            stopped = true;
            paused = false;
        }
        
        synchronized void start() {
            started = true;
            stopped = false;
            paused = false;
        }
        
	}
	
	private class AnimationLoop extends Thread {
		private Animable animable;
		
		public AnimationLoop(Animable tested) {
			animable = tested;
		}

		@Override
		public void run() {
			while (!isAnimationStopped()) {
				if (isAnimationPaused() || getSpeed() == 0 ) {
					Thread.yield();
				} else {
					try {
						if (getSpeed() == 0) {
							Thread.yield();
						} else {
							animable.animate();
							Thread.sleep(1000/getSpeed());
						}
					} catch (InterruptedException e) {
						Thread.currentThread().interrupt();
					}
				}
			}
		}
	}
}
 