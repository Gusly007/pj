package serie09;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTree;
import javax.swing.SwingUtilities;

public class GenTree extends JTree {
	
	private JFrame mainFrame;
	
	public GenTree() {
		//createModel();
		createView();
		placeComponents();
		//createController();
	}
	
	// REQUETES
	public void display() {
		mainFrame.setLocationRelativeTo(null);
		mainFrame.pack();
		mainFrame.setVisible(true);
	}
	
	// OUTILS
	private void createView() {
		mainFrame = new JFrame("Genealogy");
		mainFrame.setPreferredSize(new Dimension(400, 400));
	}
	
	private void placeComponents() {
		JButton p = new JButton("BOUTON");
		JPopupMenu jPopupMenu = new JPopupMenu();
		JMenuItem item = new JMenuItem("HI");
		item.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println(e.toString());
			}
		});
		jPopupMenu.add(item);
		p.setPreferredSize(new Dimension(300,300));
		p.setComponentPopupMenu(jPopupMenu);
		mainFrame.add(p, BorderLayout.CENTER);
	}
	
	// POINT D'ENTREE

		public static void main(String[] args) {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					new GenTree().display();
				}
			});
			
		}
}
