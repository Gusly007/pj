package serie09;

import java.awt.Component;
import java.awt.Font;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;

public class GenCellRenderer extends DefaultTreeCellRenderer {
	
	public static String FONT_NAME = "Verdana";
	public static int FONT_SIZE = 20;
	
	public GenCellRenderer() {
		super();
	}
	
	public Component getTreeCellRendererComponent(
			JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
		Person obj = (Person) ((DefaultMutableTreeNode) value).getUserObject();
		this.setBackgroundSelectionColor(obj.getGender().getBackgroundSelectionColor());
		
		this.setLeafIcon(obj.getGender().getImage());
		this.setOpenIcon(obj.getGender().getImage());
		this.setClosedIcon(obj.getGender().getImage());
		this.setFont(new Font(FONT_NAME, Font.PLAIN, FONT_SIZE));
		
		tree.setRowHeight(this.getClosedIcon().getIconHeight());
		return super.getTreeCellRendererComponent(
				tree, value, sel, expanded, leaf, row, hasFocus
				);
	}
}
