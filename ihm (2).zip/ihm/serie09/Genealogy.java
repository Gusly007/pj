package serie09;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

public class Genealogy {
	// ATTRIBUTS
	private JTree tree;
	private JFrame mainFrame;
	private DefaultMutableTreeNode root;
	
	// CONSTRUCTEUR
	public Genealogy() {
		//createModel();
		createView();
		placeComponents();
		createController();
	}
	
	// REQUETES
	public void display() {
		mainFrame.setLocationRelativeTo(null);
		mainFrame.pack();
		mainFrame.setVisible(true);
	}
	
	// OUTILS
	
	private void createModel() {
		root = new DefaultMutableTreeNode();
		root.setUserObject(new Person(Gender.MALE.name(), Gender.MALE));
		initRoot(root);
		
	}
	
	private void createView() {
		mainFrame = new JFrame("Genealogy");
		mainFrame.setPreferredSize(new Dimension(400, 400));
		tree = new JTree(root);
		tree.setEditable(true);
		GenCellRenderer renderer = new GenCellRenderer();
		tree.setCellRenderer(renderer);
		tree.setCellEditor(new DefaultTreeCellEditor2(tree, renderer, new GenCellEditor()));
	}
	
	private void placeComponents() {
		mainFrame.add(new JScrollPane(tree), BorderLayout.CENTER);
	}
	
	private void createController() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			public void valueChanged(TreeSelectionEvent e) {
				updateTitle(e.getPath());
			}
		});
		
		tree.getModel().addTreeModelListener(new TreeModelListener() {

			@Override
			public void treeNodesChanged(TreeModelEvent e) {
				updateTitle(e.getTreePath().pathByAddingChild(e.getChildren()[0]));
				
			}

			@Override
			public void treeNodesInserted(TreeModelEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void treeNodesRemoved(TreeModelEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void treeStructureChanged(TreeModelEvent e) {

			}
		});
		
	}
	
	/*
	 * Peuple l'arbre :  ARBRE TERNAIRE PARFAIT
	 */
	private void initRoot(DefaultMutableTreeNode node) {
		DefaultMutableTreeNode child;
		for (int i = 0; i < 3; i++) {
			child = new DefaultMutableTreeNode();
			child.setUserObject(new Person(Gender.values()[i % 2].name(), Gender.values()[i % 2]));
			node.add(child);
			if (node.getLevel() < 2) {
				initRoot(child);
			}
		}
	}
	
	/*
	 * 
	 */
	private void updateTitle(TreePath path) {
		String str = new String();
		Person node = (Person) ((DefaultMutableTreeNode) path.getLastPathComponent()).getUserObject();
		str += node;
		path = path.getParentPath();
		while (path != null) {
			str += ", " + node.getGender().getDesc() + " de ";
			node = (Person) ((DefaultMutableTreeNode) path.getLastPathComponent()).getUserObject();
			str += node;
			path = path.getParentPath();
		}
		mainFrame.setTitle(str);
	}
	
	// POINT D'ENTREE

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new Genealogy().display();
			}
		});
		
	}

}
