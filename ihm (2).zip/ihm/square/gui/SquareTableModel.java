package square.gui;

import javax.swing.table.AbstractTableModel;

import square.model.appli.ISquareGameModel;
import square.util.Coord;
import square.util.Player;

public class SquareTableModel extends AbstractTableModel {

	private ISquareGameModel model;
	
	public SquareTableModel(ISquareGameModel model) {
		this.model = model;
	}
	
	@Override
	public int getRowCount() {
		return model.size();
	}

	@Override
	public int getColumnCount() {
		return model.size();
	}

	@Override
	public Player getValueAt(int rowIndex, int columnIndex) {
		return model.getPlayerAt(new Coord(rowIndex, columnIndex));
	}

}
