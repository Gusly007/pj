package square;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.EnumMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;

import square.gui.SquareTableModel;
import square.model.appli.ISquareGameModel;
import square.model.appli.SquareGameModel;
import square.util.Coord;
import square.util.Player;
import square.view.GameColor;
import square.view.SquareRenderer;

public class SquareGame {
    
    private static final int SIZE = 30;
    
    private JFrame frame;
    private JTable board;
    private JButton replay;
    private Map<Player, JLabel> playerNames;
    private Map<Player, JLabel> playerScores;
    private ISquareGameModel appliModel;
    
    public SquareGame(int n) {
        createModel(n);
        createView();
        placeComponents();
        createController();
    }
    
    public void display() {
        initializeDisplay();
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void createModel(int n) {
        appliModel = new SquareGameModel(n, Player.X);
    }
    
    private void createView() {
        frame = new JFrame("Square Game");
        replay = new JButton("Recommencer");
        playerScores = createRelation();
        playerNames = createRelation();
        configureLabelNames();
        board = new JTable();
        configureBoard();
    }
    
    private void placeComponents() {
        JPanel p = new JPanel(new GridLayout(1, 0)); {
            for (Player player : Player.values()) {
                JPanel q = new JPanel(); {
                    q.add(playerNames.get(player));
                    q.add(playerScores.get(player));
                }
                p.add(q);
            }
        }
        frame.add(p, BorderLayout.NORTH);
        
        frame.add(board, BorderLayout.CENTER);
        
        p = new JPanel(); {
            p.add(replay);
        }
        frame.add(p, BorderLayout.SOUTH);
    }
    
    private void createController() {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        replay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				appliModel.startPlaying();
				board.updateUI();
			}
        });
        
		board.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Coord c = new Coord(board.rowAtPoint(e.getPoint()), board.columnAtPoint(e.getPoint()));
				if(appliModel.isValidPosition(c) && appliModel.getPlayerAt(c)==null) {
					appliModel.setPlayerAt(c);
					appliModel.setPlayer();
				}
			}
		});
		
		appliModel.addPropertyChangeListener("player", new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				displayOnlyPlayer((Player) evt.getNewValue());
			}
		});
		
		appliModel.addPropertyChangeListener("scoreOf", new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				refreshScoreOf(appliModel.getPlayer(), (int) evt.getNewValue());
			}
		});
		
		appliModel.addPropertyChangeListener("empty", new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				refreshAllScores();
			}
		});
		
		appliModel.addPropertyChangeListener("full", new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent evt) {
				displayAllPlayers();
				JOptionPane.showMessageDialog(null, "Partie Terminé ! Mais pas d'inquiétude tu peux en relancer une ;)");
			}
		});
		
		board.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				int rowSize = board.getSize().height/board.getRowCount();
				if (rowSize > 0) {
					board.setRowHeight(rowSize);
				}
			}
		});
    }
    
    private void initializeDisplay() {
        displayOnlyPlayer(appliModel.getPlayer());
        refreshAllScores();
    }
    
    private void refreshAllScores() {
        for (Player p : Player.values()) {
            refreshScoreOf(p, appliModel.getScoreOf(p));
        }
    }
    
    private void refreshScoreOf(Player p, int s) {
        JLabel label = playerScores.get(p);
        label.setText(String.valueOf(s));
    }
    
    private void displayOnlyPlayer(Player current) {
        for (Player p : Player.values()) {
            Color c;
            if (p == current) {
                c = GameColor.forPlayer(p);
            } else {
                c = frame.getBackground();
            }
            playerNames.get(p).setBackground(c);
        }
    }
    
    private Map<Player, JLabel> createRelation() {
        Map<Player, JLabel> map = new EnumMap<Player, JLabel>(Player.class);
        for (Player p : Player.values()) {
            JLabel label = new JLabel();
            map.put(p, label);
        }
        return map;
    }
    
    private void configureLabelNames() {
        for (Player p : Player.values()) {
            JLabel label = playerNames.get(p);
            label.setText("Joueur " + p + " :");
            label.setOpaque(true);
        }
    }
    
    private void configureBoard() {
    	board.setModel(new SquareTableModel(appliModel));
    	board.setBorder(BorderFactory.createLineBorder(Color.black));
    	board.setRowHeight(SIZE);
    	for (int i = 0; i < board.getColumnModel().getColumnCount(); i++) {
    		board.getColumnModel().getColumn(i).setPreferredWidth(SIZE);
    	}
    	SquareRenderer sr = new SquareRenderer();
    	board.setDefaultRenderer(Object.class, sr);
    	board.setGridColor(Color.black);
    }
    
    private void displayAllPlayers() {
        for (Player p : Player.values()) {
            Color c = GameColor.forPlayer(p);
            playerNames.get(p).setBackground(c);
        }
    }
    
    // POINT D'ENTREE
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                // un jeu de 8 lignes sur 8 colonnes
                new SquareGame(8).display();
            }
        });
    }
}
