package square.model.appli;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.EnumMap;
import java.util.Map;

import square.util.Contract;
import square.util.Coord;
import square.util.Player;
import square.util.Zone;

public class SquareGameModel implements ISquareGameModel {
    
    // ATTRIBUTS
    
    private final Player[][] data;
    private final int size;
    private final int nbOfCells;
    private final Map<Player, Integer> squaresNb;
    private Player firstPlayer;
    private Player currentPlayer;
    private int emptyCells;
    private PropertyChangeSupport changeSupport;
    
    // CONSTRUCTEURS
    
    public SquareGameModel(int s, Player first) {
        Contract.checkCondition(s >= MIN_SIZE && first != null);
        
        firstPlayer = first;
        currentPlayer = firstPlayer;
        size = s;
        data = new Player[s][s];
        nbOfCells = size * size;
        emptyCells = nbOfCells;
        squaresNb = new EnumMap<Player, Integer>(Player.class);
    }
    
    // REQUETES

    @Override
    public Player getFirstPlayer() {
        return firstPlayer;
    }

    @Override
    public Player getPlayer() {
        return currentPlayer;
    }

    @Override
    public Player getPlayerAt(Coord k) {
        Contract.checkCondition(k != null);
        
        return data[k.row()][k.column()];
    }

    @Override
    public int getScoreOf(Player p) {
        Contract.checkCondition(p != null);
        
        Integer n = squaresNb.get(p);
        return n == null ? 0 : n;
    }

    @Override
    public boolean isEmpty() {
        return emptyCells == nbOfCells;
    }

    @Override
    public boolean isFull() {
        return emptyCells == 0;
    }
    
    @Override
    public boolean isValidIndex(int n) {
        return 0 <= n && n < size;
    }

    @Override
    public boolean isValidPosition(Coord k) {
        Contract.checkCondition(k != null);
        
        return isValidIndex(k.row()) && isValidIndex(k.column());
    }

    @Override
    public int size() {
        return size;
    }
    
    // COMMANDES

    @Override
    public void addPropertyChangeListener(String n, PropertyChangeListener o) {
        Contract.checkCondition(n != null && o != null);
		if (n == null) {
			throw new AssertionError();
		}
		if (changeSupport == null) {
			changeSupport = new PropertyChangeSupport(this);
		}
		changeSupport.addPropertyChangeListener(n, o);
    }

    @Override
    public void setFirstPlayer(Player p) {
        Contract.checkCondition(p != null && isEmpty());
        
        firstPlayer = p;
    }
    
    @Override
    public void setPlayer() {
    	if (!isFull()) {
        	firePropertyChange("player", currentPlayer, currentPlayer.getNext());
            currentPlayer = currentPlayer.getNext();
    	}

    }

    @Override
    public void setPlayerAt(Coord k) {
        Contract.checkCondition(k != null && isValidPosition(k));
        Contract.checkCondition(getPlayerAt(k) == null);
        int old_score = getScoreOf(getPlayer());
        boolean old_empty = isEmpty();
        updateWith(k);
        if (isFull()) {
        	firePropertyChange("full", null, true);
        }
        firePropertyChange("scoreOf", old_score, getScoreOf(getPlayer()));
        firePropertyChange("empty", old_empty, false);
    }

    @Override
    public void startPlaying() {
        if (!isEmpty()) {
            reinit();
        }
    }
    
    // OUTILS
    
    /**
     * Effectue toutes les mises à jour concernant le placement du joueur
     *  courant en position k dans la grille.
     */
    private void updateWith(Coord k) {
        assert k != null && isValidPosition(k);
        
        data[k.row()][k.column()] = currentPlayer;
        emptyCells = emptyCells - 1;
        int s = 0;
        for (Zone z : Zone.values()) {
            if (belongToNewSquare(k, z)) {
                s = s + 1;
            }
        }
        squaresNb.put(currentPlayer, getScoreOf(currentPlayer) + s);
    }
    
    /**
     * Indique si le coup du joueur courant en position k complète le carré
     *  en zone z dans la grille.
     */
    private boolean belongToNewSquare(Coord k, Zone z) {
        assert k != null && isValidPosition(k);
        assert data[k.row()][k.column()] == currentPlayer;
        assert z != null;
        
        int r = k.row();
        int c = k.column();
        for (int i = 0; i < z.offsets().length; i++) {
            int r2 = r + z.offsets()[i][0];
            int c2 = c + z.offsets()[i][1];
            if (isValidIndex(r2) && isValidIndex(c2)) {
                if (data[r2][c2] != data[r][c]) {
                    return false;
                }
            } else {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Réinitialise le modèle.
     */
    private void reinit() {
        for (int r = 0; r < size; r++) {
            for (int c = 0; c < size; c++) {
                data[r][c] = null;
            }
        }
        firePropertyChange("player", currentPlayer, firstPlayer);
        emptyCells = nbOfCells;
        squaresNb.clear();
        currentPlayer = firstPlayer;
        firePropertyChange("empty", false, true);
    }
    
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) { 
		PropertyChangeSupport changeSupport = this.changeSupport; 
		if (changeSupport == null || (oldValue != null && newValue != null && oldValue.equals(newValue))) {
			return; 
			}
		changeSupport.firePropertyChange(propertyName, oldValue, newValue);
	}
}


