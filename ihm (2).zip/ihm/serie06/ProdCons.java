package serie06;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import serie06.event.SentenceEvent;
import serie06.event.SentenceListener;
import serie06.model.AbstractActor;
import serie06.model.Box;
import serie06.model.StdConsumer;
import serie06.model.StdProducer;
import serie06.model.UnsafeBox;
import serie06.util.Formatter;

public class ProdCons {
	// ATTRIBUTS
	private JFrame mainFrame;
	private AbstractActor[] actors;
	private JButton startButton;
	private JTextArea textArea;
	
	
	// CONSTRUCTEUR
	public ProdCons(AbstractActor[] actors) {
		this.actors = actors;
		createView();
		placeComponent();
		createControllers();
	}
	
	// REQUETES
	
	public void display() {
		mainFrame.pack();
		mainFrame.setLocationRelativeTo(null);
		mainFrame.setVisible(true);
	}
	
	// OUTILS
	
	private void createView() {
		mainFrame = new JFrame("Producteurs & Consommateurs"); {
			mainFrame.setPreferredSize(new Dimension(800, 800));
		}
		startButton = new JButton("Démarrer");
		textArea = new JTextArea(); {
			textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
			textArea.setEditable(false);
		}
		
	}
	
	private void placeComponent() {
		JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER)); {
			p.add(startButton);
		}
		mainFrame.add(p, BorderLayout.NORTH);
		mainFrame.add(new JScrollPane(textArea), BorderLayout.CENTER);
	}
	
	private void createControllers() {
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (AbstractActor actor : actors) {
					actor.start();
					Formatter.resetTime();
				}
			}
		});

		int countConsumer = 0;
		int countProducer = 0;
		for (AbstractActor actor : actors) {
			String name = null;
			if (actor.getClass() == StdProducer.class) {
				name = new String("P" + countProducer);
				countProducer ++;
			}
			if (actor.getClass() == StdConsumer.class) {
				name = new String("C" + countConsumer);
				countConsumer ++;
			}
			Formatter formatter = new Formatter(name);
			
			actor.addSentenceListener(new SentenceListener() {
				public void sentenceSaid(SentenceEvent e) {
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							textArea.append(formatter.format(e.getSentence()));
						}
					});
					
				}
			});
		}
	}

	
	// POINT D'ENTREE
	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	Box boite = new UnsafeBox();
            	AbstractActor[] actors = new AbstractActor[5];
            	actors[0] = new StdConsumer(boite ,10);
            	actors[1] = new StdConsumer(boite ,10);
            	actors[2] = new StdProducer(boite ,10);
            	actors[3] = new StdProducer(boite ,10);
            	actors[4] = new StdProducer(boite ,10);
                new ProdCons(actors).display();
            }
        });
    }
	
}
