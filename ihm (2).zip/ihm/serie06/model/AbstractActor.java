package serie06.model;

import serie06.event.SentenceListener;
import serie06.event.SentenceSupport;

public abstract class AbstractActor implements Actor {
	protected Box boite;
	private int maxIterNb;
	protected SentenceSupport sentenceSupport;
	private Thread th;
	private TaskCode taskCode;
	private final Object lock = new Object();
	
	public AbstractActor(Box box, int maxIter) {
		boite = box;
		maxIterNb = maxIter;
	}

	@Override
	public Box getBox() {
		return boite;
	}
	
	@Override
	public int getMaxIterNb() {
		return maxIterNb;
	}

	@Override
	public SentenceListener[] getSentenceListeners() {
		if (sentenceSupport == null) {
			sentenceSupport = new SentenceSupport(this);
		}
		return sentenceSupport.getSentenceListeners();
	}

	@Override
	public boolean isActive() {
		if (th == null) {
			return false;
		}
		return th.isAlive() && !th.isInterrupted();
	}

	@Override
	public boolean isWaitingOnBox() {
		return th.getState() == Thread.State.WAITING;
	}

	@Override
	public void addSentenceListener(SentenceListener listener) {
		if (sentenceSupport == null) {
			sentenceSupport = new SentenceSupport(this);
		}
		sentenceSupport.addSentenceListener(listener);
	}

	@Override
	public void removeSentenceListener(SentenceListener listener) {
		if (sentenceSupport == null) {
			return;
		}
		sentenceSupport.addSentenceListener(listener);
	}

	@Override
	public void start() {
		if (isActive()) {
			throw new AssertionError("isActive");
		}
		taskCode = new TaskCode();
		th = new Thread(taskCode);
		th.start();
	}

	@Override
	synchronized public void interruptAndWaitForInactivation() {
		if (!isActive()) {
			return;
		}
		if (taskCode == null) {
			return;
		}
		taskCode.stopped = true;
		while (isActive()) {
			th.interrupt();
			try {
				th.join();
			} catch (InterruptedException e) {
				th.interrupt();
			}
		}
			
	}
	
	synchronized void fireSentenceSaid(String string) {
		synchronized(lock) {
			if (sentenceSupport == null) {
				return;
			}
			sentenceSupport.fireSentenceSaid(string);
		}
	}
	
	// A Definir dans StdConsumer et StdProducer
	protected abstract boolean canUseBox();
	protected abstract void useBox();
	
	// OUTILS
	private class TaskCode implements Runnable {
		private boolean stopped;
		
		public void run() {
			stopped = false;
			int i = 0;
			fireSentenceSaid("Naissance");
			while (i < getMaxIterNb() && !stopped) {
				i = i + 1;
				fireSentenceSaid("Début de l'étape " + i);
				while (!canUseBox() && !stopped) {
					synchronized (boite) {	
						fireSentenceSaid("Suspendu");
						try {
							boite.wait();
						} catch (InterruptedException e) {
							stopped = true;
						}
						fireSentenceSaid("Réactivé");
					}
				}
				synchronized (boite) {
					if (canUseBox()) {
						useBox();
						boite.notifyAll();
					}
				}
				fireSentenceSaid("Fin de l'étape " + i);
			}
			if (stopped) {
				fireSentenceSaid("Mort subite");
			} else {
				fireSentenceSaid("Mort naturelle");
			}
		}
		
	}
	
}
