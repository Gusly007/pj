package serie06.model;

public class StdConsumer extends AbstractActor {

	public StdConsumer(Box box, int maxIter) {
		super(box, maxIter);
	}

	@Override
	protected boolean canUseBox() {
		return !boite.isEmpty();
	}

	@Override
	protected void useBox() {
		fireSentenceSaid("Box --> " + boite.getValue());
		boite.dump();
	}

}
