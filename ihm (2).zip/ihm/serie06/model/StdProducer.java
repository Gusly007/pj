package serie06.model;

public class StdProducer extends AbstractActor {
	
	public StdProducer(Box box, int maxIter) {
		super(box, maxIter);
	}
	
	@Override
	protected boolean canUseBox() {
		return boite.isEmpty();
	}

	@Override
	protected void useBox() {
		int value = (int) (Math.random() * 100);
		fireSentenceSaid("Box <-- " + value);
		boite.fill(value);
	}

}
