//  Affiche sur la sortie standard la liste des différents mots partagés par
//    plusieurs fichiers textes ou lus sur l'entrée standard, chaque mot étant
//    précédé de son motif et de sont nombre total d'occurrences.
//  Limitations :
//  - les mots sont obtenus par lecture sur l'entrée des suites consécutives
//    de longueur maximale mais majorée WORD_LENGTH_MAX de caractères qui ne
//    sont pas de la catégorie isspace ;
//  - Seul les mots partagés par plusieurs fichiers seront listés.
//  - Seul les 10 premières lignes de la liste seront affiché.
//  - toute suite de tels caractères de longueur strictement supérieure à
//    WORD_LENGTH_MAX se retrouve coupé.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "hashtable.h"
#include "holdall.h"
#include "cvalue.h"
#include <ctype.h>
#include <getopt.h>

// WORLD_LENGTH_MAX correspond a la taille maximal des mots avant de les couper.
#define WORD_LENGTH_MAX 63
#define MULT 2

// IN_FILE définie le caractère pour montrer l'appartenance à un fichier.
#define IN_FILE 'X'

// STOP définie le taille de la liste de mot à afficher.
#define STOP 10

//  str_hashfun : l'une des fonctions de pré-hachage conseillées par Kernighan
//    et Pike pour les chaines de caractères.
static size_t str_hashfun(const char *s);

//  scptr_display : affiche sur la sortie standard le motif, le caractère
//    tabulation,le nombre d'occurence du mot,le mot pointée par s et la fin de
//  ligne. le nombre de mot listé est limité par *stop.
//    Renvoie zéro en cas de succès, une valeur non nulle en cas d'échec.
static int scptr_display(int *stop, const char *s, cvalue *cptr);

//  rfree : libère la zone mémoire pointée par ptr et renvoie zéro.
static int rfree(void *ptr);

//  modif_valptr : Si w n'apparait pas dans la table de hachage alors ajoute w a
//   la table avec son motif et son compteur. Sinon modifie le compteur et le
//    motif du mot trouvé.
//  Chaque allocation seras ajouté a un holldall pour pouvoir libérer les
//    objets. argc et i permettent de connaitre la taille du motif et à
//    qu'elle position on devra le modifier.
//  Renvoie 0 en cas de succès, une valeur non nulle en cas de dépassement de
//    capacité.
static int modif_valptr(char *w, hashtable *ht, holdall *ha, holdall *hcptr,
    holdall *hcv, holdall *hamot, int i, int argc, int nb_opt);

// Renvoie le nombre de fichier dans lequelle apparait le mot.
static int nbfichier(char *s);

// long_options contient l'option --help.
static struct option long_options[] = {
  {"help", no_argument, 0, 'h'},
};

//  convert_maj : transforme toutes les minuscules de la chaine pointé par s en
//    majuscule.
static void convert_maj(char *s);

//  modif_motif : transforme le nième caractères de la chaine pointé par s par
//   le caractère c.
//  Renvoie s en cas de réussite ou NULL si le nième caractère n'existe pas.
static char *modif_motif(char *s, char c, int n);

int main(int argc, char *argv[]) {
  int opt_u = 0;
  int opt_p = 0;
  int opt_t = 0;
  int arg_t = 0;
  int opt_i_vide = 0;
  int arg_opt_vide = 0;
  int r = EXIT_SUCCESS;
  FILE *fichier = NULL;
  hashtable *ht = hashtable_empty((int (*)(const void *, const void *))strcmp,
      (size_t (*)(const void *))str_hashfun);
  holdall *has = holdall_empty();
  holdall *hcv = holdall_empty();
  holdall *hacptr = holdall_empty();
  holdall *hamot = holdall_empty();
  if (ht == NULL
      || has == NULL
      || hacptr == NULL
      || hamot == NULL
      || hcv == NULL) {
    goto error_capacity;
  }
  int t;
  int nb_opt = 1;
  int option_index = 0;
  int taille_mot = WORD_LENGTH_MAX;
  while (-1
      != (t
        = getopt_long(argc, argv, "upi::t::h", long_options, &option_index))) {
    switch (t) {
      case 'u':
        opt_u = 1;
        nb_opt += 1;
        break;
      case 't':
        nb_opt += 1;
        opt_t = 1;
        if (optarg != NULL) {
          arg_t = atoi(optarg);
        } else {
          arg_opt_vide = 1;
        }
        break;
      case 'i':
        if (optarg != NULL) {
          taille_mot = atoi(optarg);
        } else {
          opt_i_vide = 1;
        }
        nb_opt += 1;
        break;
      case 'p':
        nb_opt += 1;
        opt_p = 1;
        break;
      case 'h':
        fprintf(stdout, "Option --help\n");
        nb_opt += 1;
        break;
      case '?':
        goto error;
    }
  }
  char *w = malloc(sizeof(char) * (size_t) taille_mot + 1);
  if (w == NULL) {
    goto error_capacity;
  }
  for (int i = nb_opt; i < argc; i++) {
    if (argv[i][0] == '-' && argv[i][1] == '\0') {
      while (!feof(stdin)) {
        int b = 0;
        char c = (char) fgetc(stdin);
        while (opt_p == 0 ? !isspace(c) && c != EOF
            && b < taille_mot : !isspace(c) && !ispunct(c) && c != EOF
            && b < taille_mot) {
          if (opt_i_vide == 1) {
            if (b == taille_mot - 1) {
              w = realloc(w, (size_t) (taille_mot * MULT));
              taille_mot *= MULT;
            }
          }
          w[b] = c;
          c = (char) fgetc(stdin);
          b++;
        }
        w[b] = '\0';
        if (opt_p == 0 ? !isspace(c) && c != EOF : !isspace(c) && !ispunct(c)
            && c != EOF) {
          if (b == taille_mot) {
            fprintf(stderr, "*** Warning: Word '%s...' possibly sliced.\n", w);
          }
          while (opt_p == 0 ? !isspace(fgetc(stdin)) : !isspace(fgetc(stdin))
              || !ispunct(fgetc(stdin))) {
          }
        }
        if (strlen(w) != 0) {
          if (opt_u == 1) {
            convert_maj(w);
          }
          if (modif_valptr(w, ht, has, hacptr, hcv, hamot, i, argc,
              nb_opt) != 0) {
            goto error_capacity;
          }
        }
      }
      if (!feof(stdin)) {
        goto error_read;
      }
    } else {
      fichier = fopen(argv[i], "r");
      if (fichier == NULL) {
        return 0;
      }
      while (!feof(fichier)) {
        int b = 0;
        char c = (char) fgetc(fichier);
        while (opt_p == 1 ? !isspace(c) && !ispunct(c) && c != EOF
            && b < taille_mot : !isspace(c) && c != EOF
            && b < taille_mot) {
          if (opt_i_vide == 1) {
            if (b == taille_mot - 1) {
              w = realloc(w, (size_t) (taille_mot * MULT));
              taille_mot *= MULT;
            }
          }
          w[b] = c;
          c = (char) fgetc(fichier);
          b++;
        }
        w[b] = '\0';
        if (opt_p == 0 ? !isspace(c) && c != EOF : !isspace(c) && !ispunct(c)
            && c != EOF) {
          if (b == taille_mot) {
            fprintf(stderr, "*** Warning: Word '%s...' possibly sliced.\n", w);
          }
          while (opt_p
              == 0 ? !isspace(fgetc(fichier)) : !isspace(fgetc(fichier))
              || !ispunct(fgetc(fichier))) {
          }
        }
        if (strlen(w) != 0) {
          if (opt_u == 1) {
            convert_maj(w);
          }
          if (modif_valptr(w, ht, has, hacptr, hcv, hamot, i, argc,
              nb_opt) != 0) {
            goto error_capacity;
          }
        }
      }
      if (fclose(fichier) == EOF) {
        goto error_file;
      }
    }
  }
  fprintf(stderr, "--- Info: Number of distinct words: %zu.\n",
      holdall_count(has));
  int *stop = malloc(sizeof(int));
  if (stop == NULL) {
    goto error_capacity;
  }
  if (opt_t == 1) {
    if (arg_opt_vide == 1) {
      *stop = (int) holdall_count(has);
    } else {
      *stop = arg_t;
    }
  } else {
    *stop = STOP;
  }
  if (holdall_apply_context2(has,
      ht, (void *(*)(void *, void *))hashtable_search, stop,
      (int (*)(void *, void *, void *))scptr_display) != 0) {
    goto error_write;
  }
  free(stop);
  free(w);
#ifdef HASHTABLE_CHECKUP
  hashtable_display_checkup(ht, stderr);
#endif
  goto dispose;
error_capacity:
  fprintf(stderr, "*** Error: Not enough memory.\n");
  goto error;
error_read:
  fprintf(stderr, "*** Error: A read error occurs.\n");
  goto error;
error_file:
  fprintf(stderr, "Erreur durant la fermeture du fichier");
  goto error;
error_write:
  fprintf(stderr, "*** Error: A write error occurs.\n");
  goto error;
error:
  r = EXIT_FAILURE;
  goto dispose;
dispose:
  hashtable_dispose(&ht);
  if (has != NULL) {
    holdall_apply(has, rfree);
  }
  holdall_dispose(&has);
  if (hcv != NULL) {
    holdall_apply(hcv, rfree);
  }
  holdall_dispose(&hcv);
  if (hacptr != NULL) {
    holdall_apply(hacptr, rfree);
  }
  holdall_dispose(&hacptr);
  if (hamot != NULL) {
    holdall_apply(hamot, rfree);
  }
  holdall_dispose(&hamot);
  return r;
}

size_t str_hashfun(const char *s) {
  size_t h = 0;
  for (const unsigned char *p = (const unsigned char *) s; *p != '\0'; ++p) {
    h = 37 * h + *p;
  }
  return h;
}

int scptr_display(int *stop, const char *s, cvalue *cv) {
  char *c = (char *) cvalue_motif(cv);
  if (*stop <= 0 || nbfichier(c) < 2) {
    return 0;
  }
  long int *p = (long int *) cvalue_compteur(cv);
  *stop -= 1;
  return printf("%s\t%ld\t%s\n", c, *p, s) < 0;
}

int modif_valptr(char *w, hashtable *ht, holdall *has, holdall *hacptr,
    holdall *hcv, holdall *hamot, int i, int argc, int nb_opt) {
  cvalue *cv = (cvalue *) hashtable_search(ht, w);
  if (cv != NULL) {
    long int *cptr = (long int *) cvalue_compteur(cv);
    *cptr += 1;
    char *s = (char *) cvalue_motif(cv);
    if (modif_motif(s, IN_FILE, i - nb_opt) == NULL) {
      return -1;
    }
  } else {
    char *s = malloc(strlen(w) + 1);
    if (s == NULL) {
      return -1;
    }
    strcpy(s, w);
    if (holdall_put(has, s) != 0) {
      free(s);
      return -1;
    }
    long int *cptr = malloc(sizeof *cptr);
    if (cptr == NULL) {
      return -1;
    }
    *cptr = 1;
    if (holdall_put(hacptr, cptr) != 0) {
      free(cptr);
      return -1;
    }
    char *t = malloc((size_t) (argc - nb_opt + 1));
    if (t == NULL) {
      return -1;
    }
    for (int j = 0; j < argc - nb_opt; j++) {
      t[j] = '-';
    }
    t[i - nb_opt] = IN_FILE;
    t[argc - nb_opt] = '\0';
    if (holdall_put(hamot, t) != 0) {
      free(t);
      return -1;
    }
    cvalue *cv = cvalue_empty();
    if (cv == NULL) {
      return -1;
    }
    if (holdall_put(hcv, cv) != 0) {
      free(cv);
      return -1;
    }
    cvalue_add_motif(cv, t);
    cvalue_modif_compteur(cv, cptr);
    if (hashtable_add(ht, s, cv) == NULL) {
      return -1;
    }
  }
  return 0;
}

int nbfichier(char *s) {
  int p = 0;
  while (*s != '\0') {
    if (*s == IN_FILE) {
      p += 1;
    }
    ++s;
  }
  return p;
}

int rfree(void *ptr) {
  free(ptr);
  return 0;
}

char *modif_motif(char *s, char c, int n) {
  if (strlen(s) <= (size_t) n) {
    return NULL;
  }
  if (s[n] != c) {
    s[n] = c;
  }
  return s;
}

void convert_maj(char *s) {
  while (*s != '\0') {
    if (islower(*s)) {
      *s = (char) toupper(*s);
    }
    ++s;
  }
}
