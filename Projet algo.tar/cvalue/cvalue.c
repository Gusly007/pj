//  Partie implantation du module cvalue.

#include "cvalue.h"
#include <string.h>

typedef struct cvalue cvalue;

struct cvalue {
  const void *compteur;
  const void *motif;
};

cvalue *cvalue_empty() {
  cvalue *cv = malloc(sizeof *cv);
  if (cv == NULL) {
    return NULL;
  }
  cv->compteur = NULL;
  cv->motif = NULL;
  return cv;
}

const void *cvalue_compteur(cvalue *cv) {
  return cv->compteur;
}

const void *cvalue_motif(cvalue *cv) {
  return cv->motif;
}

void cvalue_add_motif(cvalue *cv,const void *s){
  cv->motif = s;
}

void *cvalue_modif_compteur(cvalue *cv, const void *xptr) {
  if (xptr == NULL) {
    return NULL;
  }
  cv->compteur = xptr;
  return (void *) xptr;
}
