//  Partie interface du module cvalue.

// le module permet de gérer deux information pour un même objet.

#ifndef CVALUE__H
#define CVALUE__H

#include <stdlib.h>

//  struct cvalue, cvalue : structure regroupant les informations permettant de
//    déterminer le nombre d'occurence d'un objet et son motif.
//  La création de la structure de données associée est confiée à la fonction
//    cvalue_empty.
typedef struct cvalue cvalue;

// les fonctions suivantes ne vérifient pas que les adresses de types cvalues*
// soient valables, ce qui peut entrainer des problèmes indéterminé.

//  cvalue_empty : crée une structure de données correspondant à une cellule
//    vide. Renvoie NULL en cas de dépassement de capacité. Renvoie un pointeur
//    vers l'objet qui gère la structure de données sinon.
extern cvalue *cvalue_empty();

// cvalue_compteur : renvoie le compteur associé à cv.
extern const void *cvalue_compteur(cvalue *cv);

// cvalue_motif : renvoie le motif associé à cv.
extern const void *cvalue_motif(cvalue *cv);

extern void cvalue_add_motif(cvalue *cv,const void *s);

// cvalue_modif_compteur : remplace l'adresse du compteur appartenant à cv par
//   l'adresse de xptr. Si xptr est NULL alors on renvoie NULL sinon on renvoie
//   l'adresse de xptr.
extern void *cvalue_modif_compteur(cvalue *cv, const void *xptr);

#endif
